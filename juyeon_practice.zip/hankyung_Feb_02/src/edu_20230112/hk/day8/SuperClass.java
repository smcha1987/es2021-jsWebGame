package edu_20230112.hk.day8;

//(부모클래스!)static 클래스에 상속하기
public class SuperClass {
//	public final class SuperClass { --> final을 작성하면 상속금지
	
	public void aa() {
		System.out.println("부모에만 작성된 메서드");
	}
	

	public void Method() {
//	public final void Method() {--> final을 작성하면 메소드 오버라이딩 금지
            System.out.println("난 이제 숨겨지겠지");
	}


} //public class SuperClass
