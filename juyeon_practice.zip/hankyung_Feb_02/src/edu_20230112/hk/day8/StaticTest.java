package edu_20230112.hk.day8;

//(자식클래스)super 클래스로 부터 상속받기
public class StaticTest extends SuperClass { //상속을 받을 때는 extends 부모 클래스명 작성
	
	
	@Override //아래 기능을 수행한다는 표시!! @ 
	public void Method() { //오버라이딩 -> 부모에 있는걸 가져와서 재정의한다!
		System.out.println("부모의 메서드를 숨기고 제가 나왔습니다.");
	} //public static void Method()

	public static void StaticMethod() // 숨김이 일어난다.
	{
		System.out.println("저는 클래스명만으로도 부를 수 있어요.");
		final int a=5;
//		a=10; // 값 변경 금지! 위에 final 인데 변경하려고 하니 오류!
	} //public static void StaticMethod()

} //public class StaticTes
