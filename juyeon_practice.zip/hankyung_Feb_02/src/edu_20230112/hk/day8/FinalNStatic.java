package edu_20230112.hk.day8;

public class FinalNStatic {
	
	public static void main(String[] args) {

		  StaticTest st = new StaticTest();
		  st.Method(); 
		   
		  SuperClass sc=new StaticTest(); //부모의 설계도
		  sc.Method(); //자식에 있기때문에 가져올 수 있는거임
		  sc.aa(); // 자식에 없는거라서 가져올 수 없는거임
		  
		  StaticTest st2=(StaticTest)sc; //부모가 더 큰 타입이기때문에 형변환(캐스팅) 해줘야함!
		  st2.StaticMethod();
		  
		  SuperClass sc2=new SuperClass(); //부모 -> 부모
		  sc2.Method();
	}
}
