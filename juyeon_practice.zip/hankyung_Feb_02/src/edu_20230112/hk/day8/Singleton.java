// Singleton pattern - 이미 있는 걸 계속 생성하면 뭔 비효율이니 그래서 Singleton pattern으로 만들어서 기능 계속 사용해보자!
package edu_20230112.hk.day8;

public class Singleton {
	
		 private static Singleton singleton; //객체를 생성해서 주소를 저장할 멤버필드
		 
	      private Singleton() {
	      } //생성자 -> private으로 만들어 main에서 new 생성하지 못하게!
	      
	      public static Singleton getInstance() { //Singleton타입의 인스턴스를 반환하자! 
	     // ↑ 객체가 생성되었는지 확인해서 생성안되면 생성해주고 생성 되었다면 바로 Singleton 객체를 반환해준다.
	    	  if (singleton==null) {
	    		  singleton=new Singleton(); //이 생성자는 private해도 같은 패키지라서 접근 가능!
			}
	    	  return singleton;
	      }
} //public class Singleton 
