package edu_20230112.hk.day8;

public class StringTestMain {
	
	public static void main(String[] args) {
		StringMethodTest smt=new StringMethodTest();
		
//  1.문자 하나를 반환: charAt(int index)
		System.out.println(smt.sTest01("한경닷컴"));
		
//	2.문자열의 인덱스를 반환 : indexOf(String s) / lastIndexOf
		System.out.println(smt.sTest02("최강최고야구"));
		
//	3.문자열의 길이 반환:length()
		System.out.println(smt.sTest03("김덕규바보"));
		
//	4.문자열의 내용을 바꾸는 기능: replace("원본","새로운 내용")
		smt.sTest04();
		
		
//★★5.문자열에서 원하는 내용만 추출하는 기능:substring(int start,int end) 
		System.out.println(smt.sTest05("덕규는 바보"));
		
		System.out.println("==========================================");

//	  연습하기!
//	 1. 해당 검색어가 존재하는 여부 판단 
//	 2. 해당 검색어의 인덱스 구해보기
//	 3. 해당 검색어를 추출해서 출력해보기
//	 4. 해당 검색어를 문자열에서 ###로 바꿔주기
		smt.search("마스크");

	} //public static void main(String[] args)
	
} //public class StringTestMain
