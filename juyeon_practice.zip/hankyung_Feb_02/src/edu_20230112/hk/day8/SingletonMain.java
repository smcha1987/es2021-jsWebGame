package edu_20230112.hk.day8;

import java.util.Iterator;

public class SingletonMain {
	
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			// Singleton 패턴 적용 안하면 새로운 객체들로 계속 나옴
			StaticTest st=new StaticTest();
			System.out.print(st);
			
			// Singleton 패턴 적용 하면 같은 객체로 계속 나옴
			Singleton slt=Singleton.getInstance(); //메서드 호출 클래스명.메서드
			System.out.println(" "+slt); //띄어쓰기하려고 한거임
			}
	}
}
