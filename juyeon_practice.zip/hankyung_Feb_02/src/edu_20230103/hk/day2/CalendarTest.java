package edu_20230103.hk.day2;

public class CalendarTest {

	public static void main(String[] args) {

	//[윤년을 판단하는 기능] : 1년 365일이지만 366일이 될 때!(2월 29일 일때)
		/* - 달력 만들 때 윤년인지 아닌지 먼저 생각해야해요~! 
		 * - 윤년인지를 판단하는 조건식이 존재!
		 *   L (1) 년도가 4의 배수 && (2) 100으로는 나누어 떨어지지 않는 수 || (3) 400으로 나눠 떨어지는 수
		 * % 모듈러스: i가 4로 나눴을 때 나머지가 0(나누어 떨어질때) 
		 * && (i%100!=0) -> 100으로는 나누어 떨어지지 않는 수 
		 * ||(i%400==0) -> 400으로 나눠 떨어지는 수*/
		for (int i = 2000; i <= 2030; i++) { //i가 참일때 i++ i를 1씩 출력 후 증가 ->i가 2030까지 출력
			if (isLeapYear(i)){
				System.out.println(i);
			}
		}
		System.out.println();
		
		System.out.println(isLeapYear(2023));//아래 있는 (int i)로 들어감  
	}

	//[윤년을 판별하는 메서드] : 윤년이면 true를 아니면 false를 반환 - 
	public static boolean isLeapYear(int i) { //boolean이 true, false를 나타내므로 넣은거고 그 자리에 void byte 등등 적어주면 됩니다!
		boolean isS=false;
		//for (int i = 2000; i <= 2030; i++) { //i가 참일때 i++ i를 1씩 출력 후 증가 ->i가 2030까지 출력
			//int i=2023;->여기에 두면 2023년만 생각하게 됩니다 --> 위로 올려야함
			if ((i%4==0&&i%100!=0)||(i%400==0)){
				//System.out.println(i);
				//조건을 만족하면 isS를 true로 저장 코드 작성
				isS=true;
				}
		return isS;
	}
	
} //class꺼임