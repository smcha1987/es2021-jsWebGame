package edu_20230103.hk.day2;

public class Operator {

	public static void main(String[] args) {
	//[관계연산자]
		System.out.println(10>5);
		if (10>5) { //if (조건식){} else {} if 조건식이 false면 else로 
			System.out.println("10이 크다");
		}else {
			System.out.println("10이 작다");
		}
	//[삼항연산자] -> if else문을 대체해서 한줄로 가능!
		System.out.println(10>5?"10이 크다":"10이 작다"); // 10이 5보다 크니? True - 10이 크다
		System.out.println(!(10>5)?"10이 크다":"10이 작다"); //! 부정의 의미 : 10이 5보다 크니? False -10이 작다
		
	//[단축연산자]
		int ii = 1;
        int sum = 1;
        // sum += ii;  sum=sum+ii
        while (sum<20) {
			sum+=ii;  //sum=sum+ii
			System.out.println(sum);
		}
        System.out.println(sum);    // sum = 11;
        
    //[증감연산자]
    	int x = 10;
		System.out.println(x++);// 10 출력 후 1증가 ⇒ 11 저장
		System.out.println(x);// 11 출력 ->출력하고 증가
		System.out.println(++x);// 1 증가 후 출력 ⇒ 12 출력
		System.out.println(x);// 12 출력->증가하고 출력
		
   //[논리연산자]
		int i = 1, j = 2, k = 3;
		System.out.println("i = " + i + ", j = " + j + ", k = " + k);
		System.out.println("i < j && j < k의 결과는 : " + (i < j && j < k)); //&& ()가 모두 참-true
		System.out.println("i < j || j < k의 결과는 : " + (i < j || j > k)); // || () 중 하나라도 -true
		System.out.println("!(i < j) || !(j < k)의 결과는 : "+(!(i < j) || !(j < k))); 
		//i가 j보다 작지않다 || j가 k보다 작지않다 --> 하나라도 맞는게 없으므로 false
		System.out.println("!(i < j) && !(j < k)의 결과는 : "+(!(i < j) && !(j < k))); 
		//i가 j보다 크지않다 && j가 k보다 크지않다 --> 두개 다 맞으므로 true
		//System.out.println("!(i < j) && !(j < k)의 결과는 : "+(!(i < j) && !(j > k))); ->false
		
		
		       }
	}

