package edu_20230103.hk.day2;

public class VariableTest {

	public static void main(String[] args) {
	//[정수타입;byt short  int long]
		// 변수선언, 초기화
		byte a=1; // byte : -128~127까지의 숫자 저장 가능
			 a=127; // b=128; 128은 범위에서 벗어나기 때문에 오류
		short sh=128;//2byte 크기
		int i=5000000;//★ 4byte 크기  <--- 자바에서 기본 정수타입
		long l=500000000L;//8byte 크기 뒤에 L를 붙여줘야함(int로 생각해줘~)
		
		//값을 표현할 때 변수, 상수, 리터럴(값 자체)
		int ii=5000000; // 변수=리터럴
		
	//[실수형]
		double d=15.2; //★ <--자바 기본 실수형
		//float f=20.5; 자바에서 실수형은 기본이 double이라서 오류남!
		float f=20.5F; //뒤에 F를 붙여줘야함(플롯으로 생각해줘~)
		
	/* [다른타입끼리 연산할 때] 
		 * ★1순위 실수형이 우선(예시. 5000000.0+15.2)
		 * ★2순위 큰 타입이 우선 */
		// int iii=ii+d;
		// L 정수+실수 조합이라 int 4byte라서 담을 수 없어서 빨간 줄이 가는거임
		int iii=(int)(ii+d);// 정수로 출력하고자 하면!
		double dd=ii+d;
		System.out.println("정수형: "+iii+",실수형: "+dd);	
		
	/*[형 변환 casting]
	 		-정수끼리 연산 */
		int intNum=2;
		byte byteNum=3;
		//int resultNum=intNum+byteNum;
		byte resultNum=(byte)(intNum+byteNum);//int+int=int형-->byte로 변환해서 저장
		//int resultNum2=(byte)intNum+(byte)byteNum;
		int resultNum2=(int)((byte)intNum+(byte)byteNum);
		//5+10X2
		System.out.println(5+10*2);//덧셈부터 하고 싶으면((5+10)*2)=30
		
		//실수+정수 연산 (실수와 정수를 계산 할때 형변환 필요!) 둘이 같이 계산 못함
		double ddd=15.5;
		int iiii=10;
		//double resultNum3=ddd+iiii;//결과 값: 25.5
		double resultNum3=(int)ddd+iiii; //결과 값: 25.0 ddd를 형변환했기때문
		System.out.println(resultNum3);
		
	}
}
