// Interface(인터페이스) 연습하기
package edu_20230120.hk.day14_book;

public interface Calc { //그냥 아무것도 안되있는 껍데기
	
	//인터페이스에 선언하는 변수는 모두 상수가 된다.
	double PI = 3.14; //상수명는 항상 대문자!
	int ERROR = -99999;
	
	//추상 메서드 (미완성된 메서드들) - {} 바디가 있으면 안됨(구현된건 사용 불가)
	int add(int num1, int num2); //기능은 모르겠지만 우선 2개 숫자 받는 add로 해둘겡..
	int substract(int num1, int num2);
	int times(int num1, int num2);
	int divide(int num1, int num2);

}
