package edu_20230120.hk.day14_book;

public class DeskTop extends Computer { //Computer 자식 클래스

	@Override
	public void display() {
		System.out.println("DeskTop display()");
	}

	@Override
	public void typing() {
		System.out.println("DeskTop typing()");
	}

}
