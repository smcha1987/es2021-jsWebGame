package edu_20230120.hk.day14_book;

// 인터페이스를 구현한다. :calc에서 받고 싶은거 강제 구현
public abstract class Calculator implements Calc{ //CompleteCalc 부모 클래스

	@Override
	public int add(int num1, int num2) {
		return num1+num2;
	}

	@Override
	public int substract(int num1, int num2) {
		return num1-num2;
	}
	//아래 두개는 구현하려고 봤더니 기능이 여기서 구체화하기 힘든 코드라 하위 클래스에서 구현하도록 합시둥!
	//--> 구현이 안된 메서드라서 abstract 추상메서드로 선언해둘게!
	@Override
	public abstract int times(int num1, int num2);

	@Override
	public abstract int divide(int num1, int num2);
	

}
