package edu_20230120.hk.day14_book;

public abstract class NoteBook extends Computer{ //Computer 자식 클래스 + MyNoteBook 부모 클래스
//	   추상클래스 ->  display만 받아주고 typing은 다른 곳으로 넘김->필수 다 안받았음 ->추상클래스야!라고 나타내줘야함.

	@Override
	public void display() {
		System.out.println("NoteBook display()");
	}
	
	// typing을 구현하지 않아 추상클래스로 선언 필요!! -->여기서 못하니까 자식아 부탁한다.


}
