package edu_20230120.hk.day14_book;

import java.io.IOException;

public class SchedulerTest {

	public static void main(String[] args) throws IOException { //IOException : 입력, 출력간의 문제를 잡아줘라
		System.out.println("전화 상담할당 방식을 선택하세요.");
		System.out.println("R: 한명씩 차례대로 할당");
		System.out.println("L: 쉬고 있거나 대기가 가장 적은 상담원에게 할당");
		System.out.println("P: 우선순위가 높은 고객 먼저 할당");
		
		//java.io java.net java.sql --> 항상 예외처리 받아야하는 애들
		int ch = System.in.read(); //키보드로 입력 받는 값을 읽어와라.
		Scheduler scheduler=null; //인터페이스 타입으로 선언 가능
		
		if (ch=='R'||ch=='r') { //'R'은 문자열 아니고  char 타입!
			scheduler=new RoundRobin(); //인터페이스에서도 다형성 가능
		}else if (ch=='L'||ch=='l') {
			scheduler=new LeastJob(); //인터페이스에서도 다형성 가능
		}else if (ch=='P'||ch=='p') {
			scheduler=new PriorityAllocation(); //인터페이스에서도 다형성 가능
		}else {
			System.out.println("지원되지 않는 기능입니다.");
			return; //메서드를 종료함(밑에 있는 코드를 더이상 실행하지 않음) (break는 반복문, 조건문을 그만시키는거고)
		}
		
		scheduler.getNextCall();
		scheduler.sendCallToAgent();
	}

}
