package edu_20230120.hk.day14_book;

public class ComputerTest {

	public static void main(String[] args) {
//		Computer c1=new Computer(); //오류 발생 -> 추상클래스라서 new를 사용할 수 없어욤. DeskTop에서 받아야해요    //display(),typing() 미구현
		Computer c2=new DeskTop(); //--> 강제 상속 받아야해요											     // 모두 구현
//		Computer c3=new NoteBook(); //오류 발생 -> 추상클래스라서 new를 사용할 수 없어욤. MyNoteBook에서 받아야해요 //typing() 미구현
		Computer c4=new MyNoteBook(); //--> 강제 상속 받아야해요											 // 모두 구현	
	}
}