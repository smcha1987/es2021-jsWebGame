//Abstract(추상클래스) 연습하기!
package edu_20230120.hk.day14_book;

public abstract class Computer {  //부모 클래스
	// abstract 추상메서드를 포함하는 클래스도 반드시 abstract를 작성해야한다!
	public abstract void display(); //노트북이냐 데스크탑에 따라 다른데 어떻게하지?! abstract을 붙여둬보자!
	public abstract void typing();  //노트북이냐 데스크탑에 따라 다른데 어떻게하지?! abstract을 붙여둬보자!
	public void turnOn() {
		System.out.println("전원을 켭니다.");
	}
	public void turnOff() {
		System.out.println("전원을 끕니다.");
	}
	

}
