//인터페이스로 다형성 연습하기!
package edu_20230120.hk.day14_book;

public interface Scheduler {
	
	public void getNextCall();
	public void sendCallToAgent();


}
