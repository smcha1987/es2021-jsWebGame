package edu_20230120.hk.day14_book;

public class MyNoteBook extends NoteBook{ //NoteBook 자식 클래스
	
	@Override
	public void typing() { 
		System.out.println("MyNoteBook typing()");
	}

}
