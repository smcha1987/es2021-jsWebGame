package edu_20230120.hk.day14_book;

public interface InterfaceTest {
	
//	interface 활용
	// 다중상속 흉내내기..-> extends...implements... --> 이거 2개 받아서 하는겅
	//	public class Test extends parentTest implements Iparent {  }
	//		     		    상속 		           인터페이스
	//	인터페이스는 다중 구현이 가능함 -> implements A,B...
	//	public class Test implements Iparent, Ichild {  }
		
//	interface 구성요소
	//상수선언
	public static final int A=10;
	
	//추상메서드
	public abstract int test();
	
	//추가적인 요소
	
	//private 메서드: 구현한 클래스에서 사용할 수 없으며, 현재 interface 내에서만 사용가능
	//				공통 기능으로 정의해야할때 사용된다.
	private void test2() {
		System.out.println("interface 내부에서 공통적으로 사용될 기능 구현");
	}
	
	//default 메서드
	public default void test3() {
		test2(); //private 메서드 호출하기
		System.out.println("인터페이스를 구현한 객체가 사용한다.");
	}
	
	//static 메서드 : InterfaceTest.test04() --> 이렇게 호출 가능(객체 생성 안하고!)
	public static void test04() {
		System.out.println("인터페이스만으로 실행시킬 수 있다.");
	}
}
