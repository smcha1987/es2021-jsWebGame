// 템플릿 메서드 연습하기!
// 템플릿 메서드: 메서드 실행 순서와 시나리오 정의
// 순서가 바뀌면 안된다는 의미기 떄문에 final 사용해야해
package edu_20230120.hk.day14_book_more;

public abstract class Car {
	
	public abstract void drive();
	public abstract void stop();
	public abstract void wiper();
	
	public void startcar() {
		System.out.println("시동을 켭니다.");
	}
	
	public void turnOff() {
		System.out.println("시동을 끕니다.");
	}
	
	final public void run() { //템플릿 메서드 ↓ 순서대로 기능 실행해달라
		startcar(); //시동켜기
		drive();    //운전
		wiper();    //와이퍼 작동
		stop();     //정지
		turnOff();  //시동끄기
	}
}
