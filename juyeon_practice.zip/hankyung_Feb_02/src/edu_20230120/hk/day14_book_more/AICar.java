package edu_20230120.hk.day14_book_more;

public class AICar extends Car {

	@Override
	public void drive() {
		System.out.println("자율주행합니다. 자동차가 알아서 방향을 전환합니다.");
	}

	@Override
	public void stop() {
		System.out.println("스스로 멈춥니다.");
	}

	@Override
	public void wiper() {
		System.out.println("비나 눈의 양에따라 빠르기가 자동으로 조절됩니다.");
	}

}
