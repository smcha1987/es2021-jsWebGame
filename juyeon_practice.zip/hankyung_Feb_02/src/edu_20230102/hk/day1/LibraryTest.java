package edu_20230102.hk.day1;

public class LibraryTest {
	//main메서드 : 자바코드를 실행시키는 특별한 메서드
	public static void main(String[] args) {
		//"안녕 자바야"
		String s="안녕 자바야";
		System.out.println(s.substring(0,2));
		//        문자열 순서   01 2 345
		// string s="안녕 자바야";으로 하면    이렇게 0~2까지 가져와라!
		// System.out.println("s".substring(0,2));
	}
//[명명법]
/*클래스명: 파스칼(클래스명- 파스칼 첫글자는 대문자로! 의미가 변화하면 또 대문자로(대-소-대)
메서드명, 변수 -> 카멜 방식
- 카멜방식, 파스칼 방식 외워두기!
클래스명과 파일명은 동일하게!! 소문자 대문자 구분해서!
글씨 중 자주색은 예약어라서 클래스명으로 사용 불가하다고 표시해주는거임!
*/

//변수 개념과 블럭변수
//메서드 밖에다가 선언하면 메서드가 끝나도 사용가능! (상위로 올리면 됩니다!)
	public boolean isPrimeTest(int num) {     // isP 변수시작
		boolean isP = true; /*변수 선언: 타입+변수명
		boolean은 true, False로 선언 가능 숫자를 쓰고 싶으면 int */
		for(int j =2; j < num; j++) {     // j 변수시작
			if (num % j == 0) {
				isP = false; //위에 있는 isP = true가 	isP = false로 바뀌됨
				break;
			}
		}     // j 변수 끝 (for문 안에서만 j변수 사용 가능)
		return isP;
	}     // isP 변수 끝 (isPrimeTest 메소드 안에서만 사용 가능하다.) 
} 
