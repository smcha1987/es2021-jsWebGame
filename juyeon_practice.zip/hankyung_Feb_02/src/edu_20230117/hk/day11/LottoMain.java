package edu_20230117.hk.day11;

import java.util.Arrays;

public class LottoMain {

	public static void main(String[] args) {
//		Lotto lotto=new Lotto();
//		int[] lotto1=lotto.lots;
//		for (int i = 0; i < 30; i++) {
//			System.out.print(lotto.makeBall()+",");			
//			lotto.makeLotto();
//		}
		
//		LottoStore store=new LottoStore();
//		store.makeLotto2();
//		System.out.println(Arrays.toString(store.lottoObj)); //로또 객체의 해시코드
//		for (int i = 0; i < store.lottoObj.length; i++) {
//			System.out.println(Arrays.toString(store.lottoObj[i].lots)); //↑store 파일에 lottoObj의 파일에 0번째 있는 lots 배열
//		}
//	Lotto 객체를 생성해서 로또6개 숫자 출력해보기
		Lotto lotto=new Lotto(); 
		int[] lotto1=lotto.lots; //lotto1의 배열 = lotto의 배열
		for (int i = 0; i < 0 ; i++) { //로또 1장 구현 완료
			lotto.makeLotto();
		}
		
//  Lotto 객체를 생성해서 로또5장 출력해보기
		LottoStore store=new LottoStore();
		store.makeLotto2();
	}

}