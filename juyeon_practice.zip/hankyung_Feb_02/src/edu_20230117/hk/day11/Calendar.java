// 달력 구현하기
package edu_20230117.hk.day11;

import java.util.Arrays;
import java.util.Iterator;

public class Calendar {
	//leap, plain 값은 고정적으로 변하지 않는 값들이어야 한다. -> static final로 해서 주소값을 고정적으로 만들기
	private static final int[] leap= {31,29,31,30,31,30,31,31,30,31,30,31}; //윤년인 경우 마지막날
	private static final int[] plain= {31,28,31,30,31,30,31,31,30,31,30,31}; //평년인 경우 마지막날
//	※ leap=new int[] {4,56,46,76} --> 이렇게 해야 {} 안에있는걸 바꿀 수 있는거고 ↑ {} 값은 바꿀 수 있음 -주소값만 고정해둔거라서!!
	
//[윤년을 판별하는 메서드] : 윤년이면 true를 아니면 false를 반환 - 1/3(CalendarTest)꺼 가져옴ㅋㅋ
	public boolean isLeapYear(int i) { 
		boolean isS=false;
			if ((i%4==0&&i%100!=0)||(i%400==0)){
				isS=true;
				}
		return isS;
	}
// 해당 월의 전년도까지 경과일을 구하기(1년도~2022년도까지의 경과일을 구하기)
	public int dates(int year) {
		int tot=0; // 합을 구하는 변수
		for (int i=1; i<year; i++) {
			if (isLeapYear(i)) { //public static boolean isLeapYear(int i)에서 윤년이면 +366  -> true
				tot+=366; 
			} else {  //윤년아니면 +365
				tot+=365;
			}
		}
		return tot; //합 변수 tot를 다른 곳에서 써야하니까 return으로 넣어줌
	}
	
//	전년도까지의 경과일 + 이번년도에 전 달까지 경과일 구하기
	public int dates(int year, int month) { //오버로딩
		//전년도까지 경과일을 구하는 코드 불러오기
		int tot=dates(year);
		//달의 마지막 : 1) 윤년인 경우 2) 윤년이 아닌 경우 - 배열을 통해 해보자
		//윤년인지 아닌지 판별해서 해당 배열의 값을 더해주는 코드를 작성 
		for (int i=1; i<month; i++) { //전달까지 구하는거니까 =하면 안됨!
			if (isLeapYear(year)) { //윤년이냐? o leap x plain
				tot+=leap[i-1];
			} else { 
				tot+=plain[i-1];
			}
		}
		return tot;
	}

//	 전년도까지의 경과일 + 이번년도에 전 달까지 경과일 + 해당 달의 1일
	public int dates(int year, int month, int day) {  //오버로딩
		return dates(year,month)+day;
		
//		dates(year) dates(year,month) dates(year,month,day)
//		2023.5월 달력 출력 ->(1년1월1일~2023년5월 1일의 경과일)%7=공백수 --> 5월 1일의 요일을 알 수 있다.
//		2023년 기준으로 볼때 2022년까지는 365,366이라는 값으로 일정한 규칙으로 경과일을 구할 수 있다.
//		2023년도 월별로 31,28,31,30.. 이런식으로 달의 일수를 일정한 규칙으로 경과일을 구할 수 있다.
		
	}
//	구하고자 하는 달의 마지막 날을 구하는 기능
	public int lastDay(int year, int month) {
		int last=0;
		if (isLeapYear(year)) {
			last=leap[month-1];
			
		} else {
			last=plain[month-1];
		}
		return last;	
	}
//	한달이 출력되는 기능
	public void calendarPrint(int year, int month) {
		Calendar cal= new Calendar();
		int dayOfWeek=cal.dates(2023, 2, 1)%7; //공백수
		System.out.println(dayOfWeek);
		
		System.out.println("\t\t\t"+year+"년 "+month+"월");
		System.out.println("일\t월\t화\t수\t목\t금\t토\t"); // \t --> tab 만큼 띄어준다.
		for (int i = 0; i < dayOfWeek; i++) {
			System.out.print("\t");
		}
		for (int i = 1; i <= cal.lastDay(year, month); i++) {
			System.out.print(i+"\t"); // 1 2 3 4
			if ((dayOfWeek+i)%7==0) { //우선순위 %,*,/먼저 하기 때문에 dayOfWeek+i를 ()에 넣어서 먼저 계산 해야해!
				System.out.println();
			}
		}
		
		
	}
	
	public static void main(String[] args) { 
		Calendar cal= new Calendar();
		int dayOfWeek=cal.dates(2023, 2, 1)%7; //공백수
		System.out.println(dayOfWeek);
		
		System.out.println("\t\t\t"+2023+"년 "+2+"월");
		System.out.println("일\t월\t화\t수\t목\t금\t토\t"); // \t --> tab 만큼 띄어준다.
		for (int i = 0; i < dayOfWeek; i++) {
			System.out.print("\t");
		}
		for (int i = 1; i <= cal.lastDay(2023, 2); i++) {
			System.out.print(i+"\t"); // 1 2 3 4
			if ((dayOfWeek+i)%7==0) { //우선순위 %,*,/먼저 하기 때문에 dayOfWeek+i를 ()에 넣어서 먼저 계산 해야해!
				System.out.println();
			}
		}
		
	}

} //public class Calendar 종료
