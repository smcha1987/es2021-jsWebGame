package edu_20230117.hk.day11;

import java.util.Iterator;

public class LottoStore {
	
//	Lotto 객체(숫자 6개 생성된 로또 1장) 여러개를 담을 배열 선언
	public Lotto [] lottoObj; //로또를 참조하는 참조타입 - 로또 객체를 저장 {Lotto,Lotto,Lotto,Lotto,Lotto}
	
	//2차원배열로 구현할 수 있지만 여기서는 사용 안함
	public int [][] lotsInt; //2차원 배열 {{1,2,3,4,5,6},{...},{....}}로 구성할건지 
	
	public LottoStore() {
		lottoObj=new Lotto[5]; //참조타입 배열, 길이 5로 초기화하여 생성
		makeLotto2();
	}
	public LottoStore(int n) {
		lottoObj=new Lotto[n]; //참조타입 배열, 길이 n로 초기화하여 생성 (오버로딩한거임!)
		makeLotto2();
	}
	
	//2차원 배열로 구성해보기
	public LottoStore(int m, int n) {
		lotsInt=new int [m][n]; //m은 장수, n은 번호개수 (현재는 6개로 설정하기)
	}
	
//	Lotto 객체를 생성해서 배열에 저장하는 메서드 만들기!
	public void makeLotto2() {
		for (int i = 0; i < lottoObj.length; i++) {
			lottoObj[i]=new Lotto();
		}
	}
}
