//1월 18일 과제
// 야구게임 구현하기
// 게임방법 
// - 수비자 번호 1~10까지의 수  (예. 1 3 7) - 랜덤 형식
// - 공격자 입력     결과
//    3  5  7     1S1B
//	  2  4  8     0S0B --> OUT!
//    7  1  3     3B
//    1  3  7     3S --> WIN! (승리)
//--> 위치 a, 숫자b / a x b o --> ball    a o b o--> strike

package edu_20230117.hk.day11_BaseBall;

import java.util.Random;
import java.util.Scanner;

public class HardCoding_BaseballGame {
	public static void main(String[] args) {

		// 수비수 - 랜덤 숫자 만들기
		Random ran = new Random();
		Scanner scan = new Scanner(System.in);
		int r1 = 0; // 1~9까지 들어갈 랜덤 숫자 1번째
		int r2 = 0; // 1~9까지 들어갈 랜덤 숫자 2번째
		int r3 = 0; // 1~9까지 들어갈 랜덤 숫자 3번째
		int count = 0; // 숫자를 담을 그릇
		while (true) {
			r1 = ran.nextInt(9) + 1;
			r2 = ran.nextInt(9) + 1;
			r3 = ran.nextInt(9) + 1;
			if (r1 != r2 && r1 != r3 && r2 != r3) { // 중복이 되지 않게 처리해주고 싶었당,,
				break;
			}
		}
		System.out.println("★★정답:"+r1+", "+r2+", "+r3);

		// 정답 맞추기
		while (true) {
			int strike = 0;
			int ball = 0;

			// 공격수 숫자 입력
			System.out.println("1번째 숫자를 입력하세요.");
			int n1 = scan.nextInt();
			System.out.println("2번째 숫자를 입력하세요.");
			int n2 = scan.nextInt();
			System.out.println("3번째 숫자를 입력하세요.");
			int n3 = scan.nextInt();

			// 결과 비교하기
			if (n1 == r1) { // n1==r1 : 스트라이크
				strike++;
			} else if (n1 == r2 || n1 == r3) { // 값은 같지만 위치는 다르면 ball
				ball++;
			}

			if (n2 == r2) { // n2 == r2 : 스트라이크
				strike++;
			} else if (n2 == r1 || n2 == r3) { // 값은 같지만 위치는 다르면 ball
				ball++;
			}

			if (n3 == r3) { // n3 == r3 : 스트라이크
				strike++;
			} else if (n3 == r1 || n3 == r2) { // 값은 같지만 위치는 다르면 ball
				ball++;
			}
			if (strike == 3) { // 3S --> WIN! (승리)
				System.out.println("You win!");
				break;
			} else if (strike == 0 && ball == 0) { // 0S0B --> OUT!
				System.out.println("OUT!");
			} else {
				System.out.println(strike + "S" + ball + "B");
			}
		}

	}

} // public class BaseballGame 마침
