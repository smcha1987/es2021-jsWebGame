//배열 (Array) : 같은 타입을 나열해둔거!
package edu_20230116.hk.day10;

import java.lang.reflect.Array;
import java.util.Arrays;

public class ArrayTest {
	
	public static void main(String[] args) {
	//배열 선언하는 방법
//	1. 변수와 값을 동시에 정의한다. 
		int[] a={1,2,3,5,6};  //1,2,3이라는 값을 넣어서 객체 생성(초기값을 넣어서 생성)
		int[] b; //변수만 선언, 자리수X, 초기값X
		//b= {236,559}; //리터럴 방식은 선언과 초기화를 따로 진행 할 수 없어!! (위에 b값에 못넣어줌)
		
		// 값을 가져오는 방법->index를 통해서 가져온다.
		int value=a[0]; //value는 1이 저장되어있겠지!
		
//	2. 변수와 값을 따로 정의할 수 있다.(new 사용해서!)
		int[] b2=null;
		b2=new int [] {1,2,3,4,5,6};
		
		int [] b3=new int [5];
		b3[0]=1; b3[1]=2; b3[2]=3; b3[3]=4; b3[4]=5;
		for (int i = 0; i < b3.length; i++) {
			System.out.print(b3[i]+",");
		}
		System.out.println(b3);
		System.out.println(Arrays.toString(b3));
		//배열은 참조타입이기때문에 Arrays.toString 없으면 해시태그 값이 나오게됨!! 
		
// Shallow Copy(얕은 복사)
//		- 참조타입에 mutable한 특성을 반영 (복사본을 변경하면 원본도 같이 변경)
		int [] c= {1,2,3,4,5,6};
		int [] d=c; //c->d로 주소값이 전달됨.(값이 전달되는게 아니라!!)
		d[2]=20; //d에서 2번째에 있는 3을 20으로 바꿈
		System.out.println("배열c:"+Arrays.toString(c));
		
// Deep Copy (깊은 복사)
//		- 복사본을 변경 시 원본에는 영향을 끼치지 않는다.
		int [] e=new int [6];
		System.arraycopy(c,0,e,0,e.length);//복사 실행  0->인덱스, length 자리길이 
		e[0]=30;  //복사 받은 쪽에서 값을 바꾼다
		System.out.println("배열e:"+Arrays.toString(e));
		
// 2차원 배열 -> 들어가는 값이 배열이다. *이중 for문 사용 자주해요!)
		int [][] aa= {{1,2,3},{4,5,6},{7,8,9}};
		int []aa_2  = aa[0];
		int aa_value=aa[0][1]; //0번째 {1,2,3}의 1번쨰꺼 꺼냄->{2}
		int aa_value2=aa[0][1];
		
		//aa[i][j]=5;(값을 넣어주면) 값을 대입하는거
		//aa[i][j]; (위치만 써주면) 값을 가져오기
		for (int i = 0; i < aa.length; i++) {
			for (int j = 0; j < aa.length; j++) {
				aa[i][j]+=10; //값을 대입해서 계산도 가능
				System.out.print(aa[i][j]+","); //값을 넣는거도 가능
			}
			System.out.println();
		}
// 2차원->1차원으로 변환
//		i*cal+j ->  i (배열의 row(큰 박스) 번호) * col (배열의 col(작은 박스) 개수) + j (index 번호)
		int [][] cc= {{1,2,3},{4,5,6}}; //2차원 배열
		int [] dd=new int[cc.length*cc[0].length];  //1차원 배열
		
		for (int i = 0; i < cc.length; i++) {
			for (int j = 0; j < cc[0].length; j++) {
				dd[i*cc[0].length+j]=cc[i][j]; 
			}
		}
		System.out.println(Arrays.toString(dd));
		
		//1차원---> 2차원으로 변환
		//[i/col][i%col]
		//[0/3][0%3] = [0][0], [1/3][1%3] = [0][1] ..... [0][2]..[1][0],[1][1]...
		int[] ee= {1,2,3,4,5,6};
		int[][] ff=new int[2][3];
		
		for (int i = 0; i < ee.length; i++) {
			ff[i/ff[0].length][i%ff[0].length]=ee[i];
		}
		for (int i = 0; i < ff.length; i++) {
			System.out.println(Arrays.toString(ff[i]));			
		}
		
	}

		//생성자를 통해 배열 초기화하기
		public int [][] bb;//맴버필드로 정의
		
		public ArrayTest() {//생성자에서 초기화하는 방법
			bb=new int [3][3];
		}
		
		public ArrayTest(int n,int m) {//생성자 오버로딩
			bb=new int [n][m];
		}
}
