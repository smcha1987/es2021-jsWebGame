// JCF(Java Collections Framework ) 연습하기 -List 계열
package edu_20230125.hk.day15;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List; //다른 패키지에 있는거 가져올때는 import 써야함

import edu_20230117.hk.day11.Lotto;

public class ListTest {
	
	public static void main(String[] args) {
		//List의 선언방법
		List list=new ArrayList(); //List 인터페이스라서 객체 생성 불가!
		list.add("가"); //["가","나"]
		list.add("나"); //  0    1 -->index
		
		// 값을 꺼낼떄 항상 해당 타입으로 다운캐스팅해야하는게 불편함이 있다!
		String s=(String)list.get(0); //담기(저장) 실패..?!
		System.out.println("s의 값은 " +s);
			// List 입장에서 생각해보면,, 어떤 값이 들어올지 몰라서 넉넉히 Object를 부모로 가지고 있는거임
		    // --> list의 기본 값이 Object(최상위 부모객체) -String으로 형변환해서 써야하는거임!
		
		//불편함을 해소해보자! 값을 저장할때 미리 타입을 변환해서 저장하자 : "제네릭" 사용하기
		List<String> list2=new ArrayList<>();
		             list2.add("가");
		String ss=list2.get(0); //다운캐스팅을 할 필요가 없이 바로 저장!
		System.out.println("ss의 값은 " +ss);
		
		list2.remove(0); //remove: index의 특정 값을 삭제해주세요.
		list2.clear(); //clear: list의 값을 모두 지운다
		System.out.println(list2.size()); //size: List에서 길이값 확인하는 메서드 /length:
		
		//Lotto 객체를 넣어보자
		List<Lotto> lottoList=new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			lottoList.add(new Lotto()); //ArrayList: 값을 저장할때 마다 인덱스는 자동 생성
		}
		for (int i = 0; i < lottoList.size(); i++) {
			System.out.println(Arrays.toString(lottoList.get(i).lots)); //객체를 출력했기때문에 해시코드가 나옴
//			System.out.println(lottoList.get(i)); //객체를 출력했기때문에 해시코드가 나옴
		}
	}
} 