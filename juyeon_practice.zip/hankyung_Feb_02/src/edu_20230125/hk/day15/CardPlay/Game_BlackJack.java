package edu_20230125.hk.day15.CardPlay;

import java.util.Scanner;

//게임판
//역할 
//- Card_1, CardDeck, Gamer, Dealer,Rule 5개 클래스 모아서 게임 진행 

public class Game_BlackJack {

	public static void play() { // 게임 진행
		System.out.println("==========BlackJack==========");
		Scanner sc = new Scanner(System.in);

		Dealer_BlackJack dealer = new Dealer_BlackJack();
		Gamer_BlackJack gamer = new Gamer_BlackJack();
		CardDeck_BlackJack cardDeck = new CardDeck_BlackJack();

		initPhase(cardDeck,gamer);
		playingPhase(sc, cardDeck, gamer);

	}

	public static void playingPhase(Scanner sc, CardDeck_BlackJack cardDeck, Gamer_BlackJack gamer) { //카드 뽑기
		String gamerInput;

		while (true) {
			String a = "종료";
			System.out.println("카드를 뽑으시겠습니까? \n종료를 원하시면 [" + a + "]를 입력하세요.");
			gamerInput = sc.nextLine(); // 입력값 다음줄에 받기

			if (a.equals(gamerInput)) {
				System.out.println("게임을 종료합니다.");
				break;
			}else {
				continue;
			}

		}
	}
	private static final int INIT_RECEIVE_CARD_COUNT = 2; //2장씩 뽑을 수 있게 숫자 고정
	public static void initPhase(CardDeck_BlackJack cardDeck, Gamer_BlackJack gamer) {
		System.out.println("딜러와 게이머 각각 처음 2장의 카드를 뽑겠습니다.");
		for (int i = 0; i < INIT_RECEIVE_CARD_COUNT; i++) {
			
			Card_1_BlackJack card = cardDeck.draw(); //cardDeck 카드 받기
			gamer.receiveCard(card); //Gamer가 뽑은 카드 받기
		}
		
	}

} // public class Game_BlackJack 종료
