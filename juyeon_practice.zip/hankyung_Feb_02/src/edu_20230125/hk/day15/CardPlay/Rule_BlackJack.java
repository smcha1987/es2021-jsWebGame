package edu_20230125.hk.day15.CardPlay;

import java.util.List;

//규칙
//역할
//- 점수 측정
//  2~10 숫자는 그대로 점수/J,Q,K는 각 11, 12, 13점으로 A는 1로 계산
//- 승패판단
//  딜러와 게이머 양쪽 모두 추가 뽑지 않음 -> 카드 오픈 -> 소유한 카드 합 : 21에 가장 가까운 쪽 승리 
// 										    	※ 단, 21 초과하면 초과한 쪽 패배

public class Rule_BlackJack {
	public int getScore(List<Card_1_BlackJack> cards) { //점수 측정 
		return getScore(cards);
	}
	
	public void getWinner(Dealer_BlackJack dealer, Gamer_BlackJack gamer) { // 승패 판단
	}

}
