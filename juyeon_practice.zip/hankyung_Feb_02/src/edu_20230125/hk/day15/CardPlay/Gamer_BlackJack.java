package edu_20230125.hk.day15.CardPlay;

import java.util.ArrayList;
import java.util.List;

//게이머
//역할
//- 딜러와 순차적으로 카드를 하나씩 뽑아 2개의 카드 소지
//- 조건과 제한 없이 얼마든 추가로 카드 뽑기 가능
//- 카드 오픈

public class Gamer_BlackJack {
	private List<Card_1_BlackJack> cards;
	
	//생성자
	public Gamer_BlackJack() {
		cards = new ArrayList<>();
	}
	
	public void receiveCard(Card_1_BlackJack card) { // 게이머가 자기의 카드를 보며 카드 추가 뽑기
		this.cards.add(card);
		this.showCards(); //카드 추가 시 현재 소유 카드 확인 필요
	}
	
	public void showCards() {
		StringBuilder sb =  new StringBuilder();
		sb.append("현재 보유한 카드 목록\n");
		
		for (Card_1_BlackJack card : cards) {
			sb.append(card.toString());
			sb.append("\n");
		}
		System.out.println(sb.toString()); //카드 추가하여 보여줄때마다 System.out 사용하면 비효율적이기때문에 최종 1번만 System.out
	}
	
	public List <Card_1_BlackJack> openCards(){
		return this.cards; //현재 갖고 있는 모든 카드들을 전달하는 역할
	}


}
