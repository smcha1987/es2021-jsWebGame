package edu_20230125.hk.day15.CardPlay;

//카드1장 
//역할
//- 모여서 카드덱이 되는 요소
//- {"♠","♣","◆","♥"} 
//  {"A","2","3","4","5","6","7","8","9","T","J","Q","K"}로 구성

public class Card_1_BlackJack {

	// 멤버필드
	public static final String[] DECK = { "♠", "♣", "◆", "♥" };
	public static final String[] STECK = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K" };
	private String card; // 카드 한장에 대한 정보(그림+숫자)
	public int point; // 포인트 받아줄 값

	public String getCard() {
		return card;
	}

	// 생성자
	public Card_1_BlackJack(int point) {
		this.point = numberToPoint(point);
		init();
	}

	// 멤버필드의 card의 "♠3" 형태로 카드 값 저장하는 메서드
	public void init() {
		// 랜덤하게 구하는 숫자를 인덱스를 활용하여 랜덤하게 숫자 구현
		int a = (int) (Math.random() * DECK.length); // DECK 인덱스길이: 0~3번째 인덱스 랜덤 생성
		int b = (int) (Math.random() * STECK.length); // STEC 인덱스길이: 0~12번째 인덱스 랜덤 생성
		card = DECK[a] + STECK[b];
	}

	@Override
	public String toString() {
		return "[" + card + "]";
	}

	@Override
	public boolean equals(Object obj) { // 중복 카드 제거 필요
		boolean isS = false;
		Card_1_BlackJack cd = (Card_1_BlackJack) obj;
		if (this.card.equals(cd.getCard())) {
			isS = true;
		}
		return isS;
	}

	@Override // equals() 오버라이딩
	public int hashCode() {
		return this.card.hashCode() + 137;
	}

	// 카드 point 할당 시키기
	private String numberToAlphabet(int number) {
		if (number == 1) {
			return "A";
		} else if (number == 11) {
			return "J";
		} else if (number == 12) {
			return "Q";
		} else if (number == 13) {
			return "K";
		}
		return String.valueOf(number);

	}

	private int numberToPoint(int number) { // 포인트가
		if (number >= 11) { // 여긴 왜 11인지 모르겠당,..
			return 10;
		}
		return number;

	}

} // public class Card_1_BlackJack 종료
