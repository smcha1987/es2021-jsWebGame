package edu_20230125.hk.day15.CardPlay;

//import java.util.Scanner;

//게임 이름 : 블랙잭
	//자신이 받은 카드 숫자 합이 21에 가까워야하고 그 숫자가 딜러 카드의 숫자 보다 높으면 이기는 게임
//게임 개요
	//딜러 1명과 게이머 1명 (2명으로 게임 진행)
	//총 52장 카드 (조커제외/"♠","♣","◆","♥"를 가진 A,2~10,K,Q,J으로 구성)
	//점수 배분: 2~10 - 숫자 그대로 카운팅, J=11, Q=12,K=13, A=1으로 카운팅
	//        (기존 규칙은 A는 1과 11 둘다 가능하지만 여기선 1로만 허용)
//게임 방법
	//1. 딜러와 게이머는 번갈아가며 1장씩 총 2장 카드 소지
	//2. 조건에 따라 추가 카드 뽑기 
	// 	※조건- 게이머: 조건과 제한 없이 추가로 카드 뽑기 가능
	//		- 딜러: 2개의 카드 합계 점수= 16점 이하면 1장 추가 뽑기 / 17점 이상이면 추가 불가
	//3. 양쪽 다 추가 뽑기 없이 카드를 오픈 하여 딜러와 게이머 중 소유한 카드의 합이 21에 가장 가까운 쪽이 승리한다.
	//	※ 단, 21 초과하면 초과한 쪽 패배

public class Main_BlackJack {
	public static void main(String[] args) { //게임 실행
		Game_BlackJack game = new Game_BlackJack();
		Game_BlackJack.play();
		
		Card_1_BlackJack card = CardDeck_BlackJack.draw();
	}

} //public class Main_BlackJack 종료
