package edu_20230125.hk.day15.CardPlay;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//딜러(컴퓨터)
//역할
//- 게이머와 순차적으로 카드를 하나씩 뽑아 2개의 카드 소지
//- 조건에 따라 카드 추가 뽑기
//  ※조건 1. 16점 이하: 반드시 1장 추가 뽑기
//		 2. 17점 이상: 추가 뽑기 불가
//- 카드 오픈

public class Dealer_BlackJack {
	private List<Card_1_BlackJack> cards;
	private static final int CAN_RECEIVE_POINT = 16;

	public Dealer_BlackJack() {
		cards = new ArrayList<>();
	}

	public void receiveCard(Card_1_BlackJack card) {// 카드 추가 뽑기
		if (this.isReceiveCard()) {
			this.cards.add(card);
			this.showCards();
		} else {
			System.out.println("카드의 총 합이 17이상 입니다. 카드를 더 이상 받을 수 없습니다.");
		}
	}
	
	public boolean isReceiveCard() {
			return getPointSum() <= CAN_RECEIVE_POINT; //https://jojoldu.tistory.com/64?category=635881 
													 // 0202 여기까지 하다가 못함
	}
	
	private int getPointSum() {
		int sum=0;
		for (Card_1_BlackJack card : cards) {
			sum=sum+Card_1_BlackJack.getPoint();
		}
		return sum;
	}

	public List<Card_1_BlackJack> openCards() {
		return openCards(); // 카드 오픈
	}

}
