package edu_20230125.hk.day15.CardPlay;

import java.util.ArrayList;
import java.util.List;

//카드덱(카드뭉치)
//역할
//- 52개의 카드 보유 (card_1의 카드 52장 모음집)
//- 52개 중 카드 1개 랜덤 선정 (게이머, 딜러에게 한장씩 조건에 맞춰서)

public class CardDeck_BlackJack {

	private static List<Card_1_BlackJack> cards; // card_1의 카드 모음집
	private static final int numOfCards = Card_1_BlackJack.DECK.length * Card_1_BlackJack.STECK.length; // 52장
//	private static final int CARD_COUNT = 13;

	// 생성자
	public CardDeck_BlackJack() {
		cards = new ArrayList<>();
		shuffle(); // CardCase 객체가 생성되면 바로 카드케이스가 준비된다.
	}

	// 카드객체를 생성해서 cards에 담는 기능
	public void shuffle() {
		// 카드객체를 생성해서 cards에 담을 때 랜덤하게 생성해서 담기 때문에 중복된 카드가 저장되지 않게 만들기
		int i = 0;
		while (true) {
			Card_1_BlackJack cc = new Card_1_BlackJack(i); // 카드 한장 만들어짐

			if (!cards.contains(cc)) { // 존재하면 실행하지 않겠다.
				cards.add(cc); // list[Card,Card,Card,Card,Card,....52개]
				i++;
			}

			if (i == numOfCards)
				break;
		}
	}

	// getter 메서드를 통해서 private 값을 가져온다.
	public List<Card_1_BlackJack> getCards() {
		return cards;
	}

	// 52장 중 남아있는 카드를 뽑기 + 뽑은 카드 카드덱에서 제거
	public static Card_1_BlackJack draw() {
		int size = cards.size();
		int select = (int) (Math.random() * size);
		Card_1_BlackJack selectedCard = cards.get(select);
		cards.remove(select);
		return selectedCard;
	}


} // public class CardDeck_BlackJack 종료
