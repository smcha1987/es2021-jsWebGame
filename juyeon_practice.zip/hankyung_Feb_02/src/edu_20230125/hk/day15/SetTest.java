// JCF(Java Collections Framework ) 연습하기 -set 계열
package edu_20230125.hk.day15;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetTest {

	public static void main(String[] args) {
		
		//set 사용하기 순서도 없고 중복 못함 - 있으면 꺼내기 
		//add로 넣어주고 iterator로 꺼내주고!
		Set<String> set =new HashSet<>(); // <>:generic // Set, HashSet 임포트 필요하니까 자동완성으로 하기!
		set.add("한");
		set.add("경");
		set.add("닷");
		set.add("컴");
		set.add("컴"); //중복된 값은 저장 불가!
		
		//↓ Iterator 패턴
		//Iterator는 인터페이스라서 혼자 객체생성을 못함 --> iterator()메서드가 객체를 생성해줌
		Iterator<String> iter=set.iterator();
//		iter.next();// 꺼내는 기능
		while (iter.hasNext()) { //hasNext() - 값이 존재하는지 확인하는 기능
			String str=iter.next(); //next() 값을 가져온다.
			System.out.println("set 값:"+str);
		}
		
	}

}
