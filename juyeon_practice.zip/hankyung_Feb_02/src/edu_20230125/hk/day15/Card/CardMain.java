package edu_20230125.hk.day15.Card;

import java.util.List;

public class CardMain{

	public static void main(String[] args) {
//		Card card=new Card(); //카드 한장 생성!
//		//다음 코드를 실행 시 [♠5]이런 형태로 출력되도록 코드를 추가하세요.
//		System.out.println(card.toString()); //card.toString --> toString 생략되어있는거임
		
//		List<String> list=new ArrayList<>();
//		list.add("가");
//		System.out.println("해당객체가 존재하는가?"+list.contains("가"));
		
		CardCase cardcase=new CardCase(); //카드 52장이 만들어짐
		List<Card> cList=cardcase.getCards(); //cards를 가져온다.
		for (int i = 0; i < cList.size(); i++) {
		//      Card 객체.card--> "[♠5]" //실제 카드 값을 출력
//			String card=cList.get(i).getCard();
//			System.out.println(card+"\t");
//			System.out.print(cList.get(i)+"\t");
			//10장씩 줄바꿔서 출력하기
			System.out.print(cList.get(i)+"\t"); //10장 출력하고 실행되게..
			if ((i+1)%10==0) { //0번째를 10으로 나누면 0이 나오니까 +1을 해준거임!
				System.out.println();
			}
		}
	}
}