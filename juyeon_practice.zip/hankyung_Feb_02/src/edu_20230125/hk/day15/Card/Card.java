package edu_20230125.hk.day15.Card;

//Card 객체가 카드 한장을 뜻함!
public class Card { //--> 카드 한장 만드는거임
	//카드를 만들기 위한 필드를 선언해보자!
	public static final String [] DECK= {"♠","♣","◆","♥"}; //상수 선언 static final + 상수는 항상 대문자!
	public static final String[] STECK = {"A","2","3","4","5","6","7","8","9","T","J","Q","K"};
	//                          ↑ 참조타입: 주소값을 변경 못하는거지 {} 내용은 바꿀 수 있음
	// ↓ 카드 한장에 대한 정보(그림+숫자)
	private String card; //"♠3"이런식으로 카드 나오면 바뀌지 않게!
	
//	public Card(String hk) {
//		ID=hk; //final을 붇이면 값 변경 금지(상수) ID를 선언하고 생성자에서 초기화해주면 가능!
	           // --> 객체 단위로 봤을떄 변경이 되는 값이라 static을 붙여야 진정한 상수를 표현 가능!
//	}
	
	//생성자
	public Card () {
//		ID[0]="10"; //안에 값은 바뀐다.
//		ID=new String[] {"1","20"};//참조타입은 주소값 변경 금지
		init();
	}
	
	// ↓ 멤버필드인 card의 get 메서드
	public String getCard() {
		return card;
	}

	// ↓ 멤버필드의 card의 "♠3" 형태로 카드 값을 저장하는 메서드 구현 (랜덤하게 만들어서 저장해야함!) //init
	public void init() {
		//랜덤하게 구하는 숫자를 인덱스로 활용할 계획이라 0부터 필요 (String을 안써도 되는거임)
		int a=(int)(Math.random()*DECK.length); //DECK 인덱스길이: 0~3번째 인덱스 랜덤 생성
		int b=(int)(Math.random()*STECK.length); //STEC 인덱스길이: 0~12번째 인덱스 랜덤 생성
		card=DECK[a]+STECK[b]; //인덱스를 랜덤하게 나오게 하는거임!
	}
	
	//코드 실행 시 [♠5]이런 형태로 출력되도록 코드를 추가하세요.
	@Override
		public String toString() {
			return "["+card+"]";
		}
	
	//equals() 오버라이딩 --> 중복되는 카드 제거하기 위해 오버라이딩해주기!
	//card.equals(card)
	@Override
		public boolean equals(Object obj) {
		boolean isS=false;
		Card cd=(Card)obj; //equals Object기 떄문에 Card로 형변환
		 //현재 클래스의 card(멤버필드)와 비교하려는 Card 객체의 card(멤버필드)를 비교한다
		if (this.card.equals(cd.getCard())) {
			isS=true;			
		}
			return isS;
		}
	
	//equals() 오버라이딩 할때는 hashCode도 오버라이딩 해야한다.
	@Override
		public int hashCode() {
			return this.card.hashCode()+137;
		}
}