// JCF(Java Collections Framework ) 연습하기 -Map 계열
package edu_20230125.hk.day15;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapTest {

	public static void main(String[] args) {
		//Map 사용하기 --> myBatis 프레임워크에서 많이 사용
		//키(Key)와 값(value)를 한 쌍으로 대입
		Map<String, String> map=new HashMap<>(); //<>에 타입을 넣어줘야함 // 생성
		map.put("하나", "한경");
		map.put("둘", "닷컴");
		map.put("셋", "IT");
		System.out.println("Map에서 값 가져오기: "+map.get("하나"));  //Key값을 출력하면 value가 따라 나온다.
		
		// ↓ Iterator를 통해서 대입된 모든 것을 얻는다.
		// map의 키값을 Set에 담아서 반환한다. 
		// map에서 바로 Iterator 갹채를 반환하는 메서드가 없어서 key값을 Set 객체로 반환하는 keySet메서드를 이용한다. 
		// --> set에는 Iterator() 존재
		Set<String> setkeymap=map.keySet(); //Set 객체 반환 + 생성
		Iterator<String> iterkeymap=setkeymap.iterator(); //Iterator 객체 반환
		while (iterkeymap.hasNext()) {//hasNext() - 값이 존재하는지 확인하는 기능
			String str=iterkeymap.next();///next() 값을 가져온다.
			System.out.println(map.get(str));
		}
	}

}
