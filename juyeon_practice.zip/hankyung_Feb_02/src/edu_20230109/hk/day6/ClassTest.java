package edu_20230109.hk.day6;

public class ClassTest { //클래스 : 설계도,틀 --> 아직 사용 불가(붕어빵 틀이기 때문에)
	
//	멤버필드 : 클래스 안에 선언된 변수들(클래스에서 정의하는 저장공간, 클래스의 정보를 담는 공간) 
//			 L클래스가 소멸되기 전까지 살아있음
	public int a; //인스턴스 변수 private: 해당 패키지 안에서만 접근 가능 ,public: 다른 패키지에서도 어디서나 접근 가능
	public static int b; //클래스 전역 변수
	
// 생성자는 객체 생성할 떄 딱 한번 실행된다!
// default 생성자 - 파라미터 없는 생성자(기본생성자)
	public ClassTest() { 
		super(); //부모의 생성자를 호출하는 친구! (생략도 가능하지만 쓸 때는 가장 상단에서 사용해야해)
//		ClassTest classTest=new ClassTest(); //객체생성? 생성자를 호출하는거!
//		this.a=10;//this: 자기자신을 나타냄/현재 클래스에 a라는 변수에 10을 넣겠다 (멤버필드 a의 값을 10으로 초기화한다.)
		System.out.println("생성자 호출");
	} //public ClassTest()
	
//	오버로딩: 파라미터의 타입과 개수를 다르게 구성하여 이름으로 작성가능하게 하는 기법
//	그룹핑하기도 좋고 이름 짓기가 힘드니까 그걸 방지하기도 함!
//	생성자 오버로딩 
//	*주의사항 : default생성자를 생략 할 수 없다.(default만 사용할때는 생략가능하지만 오버로딩 할때는 생략불가!)
	public ClassTest(int n) {
		this.a=n; //멤버필드 a의 값을 n으로 초기화한다.
		System.out.println("생성자 오버로딩");
	} //public ClassTest(int n)
	
//	메서드 : 클래스의 기능 구현을 담당함
//	메서드의 유형 : 1)static/non-static 2)반환타입 O/X 3)파라미터 O/X
	
// non-static 메서드
// 	문법: 객체생성한 뒤 객체명. 메서드명()
	
	public void test() {
		System.out.println("클래스의 기능을 담당하는 메서드");
	}//public void test()
	
//	static 메모리에 이미 올라가 있기 때문에 따로 객체생성을 할 필요 없음
// 	문법: 클래스명. 메서드명()--> 자주 사용하는 기능 뎨)Math클래스 : 수학적인 기능 제공
	public static void staticTest() {
		System.out.println("static 메서드");
	}
	
} //public class ClassTest
