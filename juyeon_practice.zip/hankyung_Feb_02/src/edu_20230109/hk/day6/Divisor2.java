package edu_20230109.hk.day6;

import java.util.Iterator;

public class Divisor2 {
	
	
	
	public static void main(String[] args) {
//		System.out.println(sumDivisor(220)+":"+sumDivisor(sumDivisor(220)));
				
		int num=220;
		if(num==sumDivisor(sumDivisor(num))) { // 220의 친화수를 확인하는 조건
			// sumDivisor(sumDivisor(num)) == 	sumDivisor(284)	   // 안에 메소드가 먼저 실행됩니다! 
			System.out.println(num+"의 친화수는 "+sumDivisor(num));
		}
		
		
		
		if((sumDivisor(228)==220 && sumDivisor(220)==228)) {
		System.out.println(num+"의 친화수는 "+sumDivisor(num));
		}
		System.out.println("==============");
		
		amicable(2,5000); //public static void amicable(int s,int e) 
		// -> 파라미터를 받기로 했으면 amicable(1,1000)에 꼭 써주기
		System.out.println("==============");
		
		perfectNum(1000);
		
	} //public static void main(String[] args)
	
/* 친화수 구하기
	- 필요한 기능 구현: 진약수의 합을 구하는 메서드 추가 구현 */
	
	//1. 진약수의 합을 구하는 메서드(220의 약수 중 자신의 수를 제외한 합을 구하는 메서드)
	/* 합을 구했다.-> 그 합을 어딘가에 쓸까>=? ->okay(반환이 필요하다!) 
	-> 반환 타입을 써야겠군 -> 합? 숫자니까 int를 써봐야겠군 */
	public static int sumDivisor(int a){ //int가 반환타입이야!! static이 아니라!!
	// 합을 구하는거? 1~100까지 합을 구해보자! 우리는 이걸 해봤으니 이걸 써볼까~~~
		
		int sum=0;
		for (int i = 1; i <a; i++) {
			if (a%i==0) { //100의 약수는? 100을 i로 떨어질 떄 나머지가 0이 되면!
				sum+=i;
				
			}
		}
		
		/* 
		 *  
		 *   
		 *   
		 * 
		 */
		
		return sum; //sum을 반환을 해주고 끝나야지!
	} //public static int sumDivisor(int a)
	
// 두 수의 친화수 관계를 구하는 메서드
	public static void amicable(int s,int e) {//반환 필요가 없으므로 void 사용!+외부에서 사용할거라서 ()안에 선언
			// 범위를 설정해서 그 범위안에 친화수를 출력하자
		for (int i = s; i < e; i++) {
			/* 완전수-자기자신이랑 같은 수가 구해짐->
				완전수의 조건을 생각해서 현재 실행 결과에서는 완전수 제외 시키기*/
			if (i!=sumDivisor(i) && i==sumDivisor(sumDivisor(i))) { 
			//주연이가 쓴거: (i==sumDivisor(sumDivisor(i))&& sumDivisor(i)%i!=0)
				System.out.println(i+":"+sumDivisor(i));
			}
		}
	} //public void amicable() 
		
// 완전수를 구하는 프로그램
		public static void perfectNum(int num) {
			for (int i = 1; i < num; i++) {
				
				if (sumDivisor(i)==i) {
//				System.out.println(i+"은 완전수이다.");
					System.out.printf("진약수의 합:%d \n",sumDivisor(i));
					System.out.printf("%d은 완전수이다.\n",i);  // \n은 줄바꿈
					//printf ->문자열 안에서도 변수로 인정 가능 %d=정수 "내용",i -> i는 변수 선언
				}
				
			}
		
	
		} //public void perfectNum()
		
		

} //public class Divisor2
