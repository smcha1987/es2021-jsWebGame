package edu_20230105.hk.day4;

public class PracticeForIF {

	public static void main(String[] args) {
		
		// 과제) 1~100까지 정수의 총 합 출력
//		int sum=0; //연산하면서 구해지는 합을 저장할 공간(변수) (1+2(=3)+3(=6)+4...)
//		int i=1;
//		int sum2=sum+i; //0+1
//	--> 이건 안되겠군. -변수는 하나의 값을 저장하지만 마지막 값이 최종값이라서 변수를 계속 선언해야하는구만
//	*마지막에 저장한 값이 최종값 -> 변수 하나만 선언하고 중간에 구해지는 합을 저장
	
		int sum=0; // 합을 구하는 변수
		for (int i=1; i<=100; i++) {
			sum+=i;//	sum=sum + i; 단축연산자
			}
		System.out.println("1~100까지의 총합은?:"+sum);
		
//	과제+)1~1000까지 정수의 총 합 출력

	
// 과제) 1~100까지의 정수 중 3의 배수 총 합 출력하기
		int sum2 = 0;                    // 합을 구하는 변수 + 중복한 이름으로 선언 불가
		for (int j=1; j <=100; j++) { // 1~100까지 돌리기
			if (j%3 == 0) // i를 3으로 나눴을때 0이 나머지냐? 맞으면 내보내라
				sum2 += j;
		}
		System.out.println("3의 배수입니다 :"+sum2);
		
//		과제+)1~1000까지 정수의 총 합 중 5의 배수 출력

// 과제) 주사위의 합이 5가되면 실행을 멈추고 5가 아니면 계속 실행하는 코드 작성
/* 랜덤 숫자 구하기 
 몇번을 돌려야 5가 될지 몰라! 그래서 for문 보다 while문이 더 좋을듯*/
// 		int number1=(int)(Math.random()*6+1);
// 		int number2=(int)(Math.random()*6+1);
// 		System.out.println("("+number1+","+number2+")");
		
		while(true) { //while문 작성 시반복문 빠져나가는 코드 !!오타조심! 
			int number1=(int)(Math.random()*6+1); //주사위1
			int number2=(int)(Math.random()*6+1); //주사위2
			System.out.println("("+number1+","+number2+")");
			
			if (number1+number2==5) {
				System.out.println("합이 5가 되어 종료합니다.");
				break;  // break가 최종이라서 여기에선 syso를 사용할 수 없음
			}
		}

	} //public static void main
} //public class