package edu_20230105.hk.day4;

public class StarView {

	public static void main(String[] args) {

//	별쌓기
/*	0  ★
  	1  ★★ 
  	2  ★★★
  	3  ★★★★
  	4  ★★★★★
 */
	
		for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
			for (int j = 0; j < i+1; j++) {  //i에서 1을 더하면 되는구나! 규칙을 찾았닷!
				System.out.print("★"); // println (세로형식) print (가로형식)
			}
			System.out.println(); //줄바꿈
		}
		System.out.println("============================="); //
/*	0  ☆☆☆☆★
  	1  ☆☆☆★★ 
  	2  ☆☆★★★
  	3  ☆★★★★
  	4  ★★★★★ 을 만들어보자 */
		
		int num=5;  //변수를 선언하면 숫자가 바뀌어도 아래 메서드를 안바꿔도 괜찮다
		for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
			for (int j = 0; j < num-1-i; j++) {
				System.out.print("☆");
			}
			for (int j = 0; j < i+1; j++) { 
				System.out.print("★"); // 별을 옆으로 출력
			}
			
			System.out.println(); //줄바꿈
		}
		System.out.println("============================="); //
		
		
/*
    ★
   ★★★
  ★★★★★
 ★★★★★★★
★★★★★★★★★     */
		
		int num6=5;  //변수를 선언하면 숫자가 바뀌어도 아래 메서드를 안바꿔도 괜찮다
		for (int i = 0; i < num6; i++) {  //1번 돌때 안에 for문이 반복
			for (int j = 0; j < 4-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < 1+2*i; j++) { 
				System.out.print("★"); // 별을 옆으로 출력
			}
			
			System.out.println(); //줄바꿈
		}
		System.out.println("============================="); //

/*
★★★★★★★★★
 ★★★★★★★
  ★★★★★
   ★★★
    ★     */
			
			for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
				for (int j = 0; j < i; j++) {
					System.out.print(" ");
				}
				for (int j = 0; j < 9-2*i; j++) { 
					System.out.print("★"); // 별을 옆으로 출력
				}
				
				System.out.println(); //줄바꿈
			}
			System.out.println("============================="); //

			
		
/* 
★★★★★
 ★★★★
  ★★★
   ★★
    ★     */
			
			
			for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
				for (int j = 0; j < i; j++) {
					System.out.print(" ");
				}
				for (int j = 0; j < 5-i; j++) { 
					System.out.print("★"); // 별을 옆으로 출력
				}				
				System.out.println(); //줄바꿈
			}
			System.out.println("============================="); //
			
//	*주연이가 만든거	
//			int num3=5; 
//			for (int i = 0; i < num3; i++) {  //1번 돌때 안에 for문이 반복
//				for (int j = 0; j < i; j++) { 
//					System.out.print(" "); // 별을 옆으로 출력
//				}
//				
//				for (int j = 0; j < num3-i; j++) {
//					System.out.print("★");
//				}
//				System.out.println(); //줄바꿈
//			}
//			System.out.println("============================="); //
			
/* 
★★★★★
★★★★ 
★★★  
★★   
★     */			
			int num2=5; 
			for (int i = 0; i < num2; i++) {  //1번 돌때 안에 for문이 반복
				for (int j = 0; j < num2-i; j++) { 
					System.out.print("★"); // 별을 옆으로 출력
				}
				
				for (int j = 0; j < i; j++) {
					System.out.print(" ");
				}
				System.out.println(); //줄바꿈
			}
			System.out.println("============================="); //

/*
		    ★
		   ★★★
		  ★★★★★
		 ★★★★★★★
		★★★★★★★★★     */
				
				for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
					for (int j = 0; j < i; j++) {
						System.out.print(" ");
					}
					for (int j = 0; j < 9-2*i; j++) { 
						System.out.print("★"); // 별을 옆으로 출력
					}
					
					System.out.println(); //줄바꿈
				}
				System.out.println("============================="); //
				
/*
    ★
   ★★★
  ★★★★★
 ★★★★★★★
★★★★★★★★★
 ★★★★★★★
  ★★★★★
   ★★★
    ★        */
					
				for (int i = 0; i < 5; i++) {  //1번 돌때 안에 for문이 반복
					for (int j = 0; j < 4-i; j++) {
							System.out.print(" ");
						}
					for (int j = 0; j < 1+2*i; j++) { 
							System.out.print("★"); // 별을 옆으로 출력
						}
						System.out.println(); //줄바꿈
					}
						
				for (int i = 0; i < 4; i++) {  //1번 돌때 안에 for문이 반복
						for (int j = 0; j < i+1; j++) {
								System.out.print(" ");
							}
						for (int j = 0; j < 7-2*i; j++) { 
								System.out.print("★"); // 별을 옆으로 출력
							}
							System.out.println(); //줄바꿈
					}
					System.out.println("============================="); //
	} //public class

} //public static void main
