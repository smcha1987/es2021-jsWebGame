//Thread 실습!
package edu_20230130.hk.day18;

//java.lang 패키지는 기본 패키지라서 import 설정 필요 없음
public class MyThread1 extends Thread { //Thread--> 기본 패키지 상속 받아서 사용필요! extends Thread
	
	//생성자 
	public String threadName;
	
	public MyThread1() {
	}
	
	public MyThread1(String s) {
		this.threadName=s;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < 100; i++) {
			System.out.println(threadName+i+": Thread 상속 받아서 실행!");
		}
	}

}
