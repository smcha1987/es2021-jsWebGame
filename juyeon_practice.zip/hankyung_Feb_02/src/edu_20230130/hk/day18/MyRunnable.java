//Runnable 실습!
package edu_20230130.hk.day18;

public class MyRunnable implements Runnable{ //Runnable은  implements 사용해서 가져와야함!

	@Override
	public void run() {
		for (int i = 0; i < 100; i++) {
			System.out.println("Runnable 인터페이스를 구현하여 실행");
			
		}
		
	}

}
