//Thread 실습!
package edu_20230130.hk.day18;

public class ThreadMain {
	
	public static void main(String[] args) {
		
		//↓Thread
		Thread t1=new MyThread1("t1");
		Thread t2=new MyThread1("t2");
		Thread t3=new MyThread1("t3");
		
		//쓰레드 작업 시작!!
		t1.start();
		t2.start();
		t3.start();
		
		try {
			t1.sleep(15000); //1000이 1초 (15000=15초), 지연을 나타내는 것 : sleep
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		//↓Runnable
//		Runnable rn=new MyRunnable();
//		Thread tr=new Thread(rn);
//		
//		tr.start();
	}

}
