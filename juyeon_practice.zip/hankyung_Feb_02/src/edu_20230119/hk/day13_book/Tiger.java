// 다형성 연습하기
package edu_20230119.hk.day13_book;

public class Tiger extends Animal {
	
	@Override
	public void move() {
		System.out.println("호랑이는 네발로 뜁니다.");
	}
	public void hunting() {
		System.out.println("호랑이가 사냥을 합니다.");
	}
	
//	public void move() {
//		System.out.println("호랑이는 네발로 뜁니다.");
//	}

}
