// 다형성 연습하기
package edu_20230119.hk.day13_book;

public class Animal {
	
	public void move() {
		System.out.println("동물이 움직입니다.");
	}

}
