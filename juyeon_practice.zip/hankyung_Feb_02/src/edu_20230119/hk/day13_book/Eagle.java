// 다형성 연습하기
package edu_20230119.hk.day13_book;

public class Eagle extends Animal{
	
	@Override
	public void move() {
		System.out.println("독수리는 하늘을 납니다.");
	}
	
	public void flying() {
		System.out.println("독수리가 날아갑니다.");
	}
	
//	public void move() {
//		System.out.println("독수리는 하늘을 납니다.");
//	}

}
