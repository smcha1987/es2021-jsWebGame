// 다형성 연습하기
package edu_20230119.hk.day13_book;

public class Human extends Animal{
	
	@Override
	public void move() {
		System.out.println("사람은 두 발로 걷습니다.");
	}
	
	public void readBook() {
		System.out.println("사람이 책을 읽습니다.");
	}
	
	
//	public void move() {
//		System.out.println("사람은 두 발로 걷습니다.");
//	}

}
