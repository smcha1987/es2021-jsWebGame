package edu_20230118.hk.day12_book;

public class CustomerTest {

	public static void main(String[] args) {
		
		Customer[] custArray=new Customer[5]; //고객 5명짜리 준비 완료! [,,,,]
		
		Customer custLee=new Customer(10010,"이순신"); 
		Customer custShin=new Customer(10020,"신길동");
		Customer custCha=new GoldCustomer(10030,"차성민");
		Customer custRyu=new GoldCustomer(10040,"류지연");
		Customer custKim=new VIPCustomer(10050,"김덕규",12345); 
		
		custArray[0]=custLee;
		custArray[1]=custShin;
		custArray[2]=custCha;
		custArray[3]=custRyu;
		custArray[4]=custKim; // 생성자만 실행된 상태
		
		//향상된 for문: 인덱스를 사용하지 않고 값을 꺼내준다.
		for (Customer customer : custArray) {
//			System.out.println(customer.showCustomerInfo());
		}
								// --------- ↑ 생성자만 실행된 상태
		
		int price=10000;
		for (Customer customer : custArray) { //custArray 배열에 있으면 꺼내오삼!
			int cost=customer.calcPrice(price); //할인된 금액이나 포인트 여기 쌇임
			System.out.println(customer.getCustomerName()+"님이 "+cost+"원 지불하셨습니다.");
			System.out.println(customer.getCustomerName()+"님의 현재 보너스 포인트는 "
														 + customer.bonusPoint+"점 입니다.");
		}

	}

}
