package edu_20230118.hk.day12_book;

public class CustomerTest1 {

	public static void main(String[] args) {
//		Customer customerLee=new Customer(); //고객 한명생성(고객추가)
//		customerLee.setCustomerID(10010);
//		customerLee.setCustomerName("이순신");
//		customerLee.bonuspoint=1000;
//		System.out.println(customerLee.showCustomerInfo());
//		System.out.println("할인율 계산한 가격:"+customerLee.calcPrice(10000));
		
//		Customer customerkim=new VIPCustomer(); //고객 한명생성(고객추가)
//		customerkim.setCustomerID(10020);
//		customerkim.setCustomerName("김국자");
//		customerkim.bonuspoint=10000;
//		System.out.println(customerkim.showCustomerInfo());
//		System.out.println("할인율 계산한 가격:" + customerkim.calcPrice(10000) + ", 보너스포인트:" + customerkim.bonuspoint);
		
		Customer customer=new Customer(10011, "류주연");
		System.out.println("결제금액:"+customer.calcPrice(10000)); //결제하기
		System.out.println(customer.showCustomerInfo());
		
		VIPCustomer vip=new VIPCustomer(10012, "김덕규", 20010);
		System.out.println("결제금액:"+vip.calcPrice(10000)); //결제하기
		System.out.println(vip.showCustomerInfo());
		
		// 부모의 타입으로 자식을 생성한 경우? : 자동 캐스팅 --> 큰 타입에 작은 타입 대입
		Customer vipCustomer=new VIPCustomer(10013, "차성민", 20010);
		System.out.println("결제금액:"+vipCustomer.calcPrice(10000)); //결제하기
		System.out.println(vipCustomer.showCustomerInfo());
		
	}

}
