package edu_20230118.hk.day12_book;

public class Customer {
//멤버필드
//	private int customerID; ////고객 아이디 - 클래스에서만 접근 가능(private)
	protected int customerID; //protected : 상속일 경우 어디서나 접근 가능(public)
							  //상속이 아닐 경우 default 같은 패키지 내에서만 접근 할 수 있다.
	protected String customerName; //고객 이름
	protected String customerGrade; //고객 등급
	int bonusPoint; //보너스 포인트 - 패키지에서만 접근 가능 (default)
	double bonusRatio; // 적립비율 - 패키지에서만 접근 가능

//디폴트 생성자
	public Customer() {
		initCustomer();
//		System.out.println("Customer()생성자 호출");
	}
	
//생성자 오버로딩 // 초기화할 멤버필드를 매게변수로 초기화 (멤버필드 받아오기 : source->using field)
	public Customer(int customerID, String customerName) {
//		super();
		this.customerID = customerID;
		this.customerName = customerName;
		initCustomer(); 
//		System.out.println("Customer(int, String )생성자 호출");
	}
//	모든 생성자에서 공통으로 초기화할 내용들을 따로 메서드에 정의해놓고 호출해서 사용하자!
	private void initCustomer() {
		customerGrade ="SILVER";//기본등급
		bonusRatio = 0.01; //보너스 포인트 기본 적립 비울
	}
	
//	적립을 위한 메서드
	public int calcPrice(int price) {
		bonusPoint+=price*bonusRatio;
		return price; 
	}

	public String showCustomerInfo() {
		return customerName+"님의 등급은 "+customerGrade+"이며, "
				+ "보너스 포인트는 "+bonusPoint+"입니다.";
	}
	
//getter setter 메소드 (은닉화) --> 멤버필드의 private,protected를 외부에서도 간접적으로 사용할 수 있게!!
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerGrade() {
		return customerGrade;
	}

	public void setCustomerGrade(String customerGrade) {
		this.customerGrade = customerGrade;
	}


}
