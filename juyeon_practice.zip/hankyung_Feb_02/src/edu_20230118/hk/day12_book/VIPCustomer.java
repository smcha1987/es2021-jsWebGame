package edu_20230118.hk.day12_book;

public class VIPCustomer extends Customer {
//멤버필드 (부모꺼 상속해줬으니 부모꺼 + 아래있는거)
	private int agentID; // VIP 고객 담당 상담원 아이디 --> 은닉화
	double saleRatio; // 할인율

//디폴트 생성자
	public VIPCustomer() { 
		super(); //자식 생성자를 호출하면 부모 생성자도 함께 호출되고 자식 생성자에 부모 생성자 super 숨겨져있음
		customerGrade = "VIP"; // 고객등급 VIP
		bonusRatio = 0.05; // 보너스 적립 5%
		saleRatio = 0.1; // 할인율 10%
		System.out.println("VIPCustomer()생성자 호출");
	}
	
//생성자 오버로딩 
	public VIPCustomer(int customerID, String customerName, int agentID) {
		super(customerID, customerName); //부모의 생성자 호출(매개변수가 있는 생성자)
		customerGrade = "VIP"; // 고객등급 VIP - 부모 멤버필드
		bonusRatio = 0.05; // 보너스 적립 5% - 부모 멤버필드
		
		saleRatio = 0.1; // 할인율 10%
		this.agentID=agentID; //자식에  고유한거! //파라미터랑 이름이 같은거 헷갈릴 수 있으니 this 써준거임
//		System.out.println("VIPCustomer(int,String,int) 생성자 호출");
	}
//메서드 오버라이딩 : 부모의 메서드를 자식이 재정의해서 사용하는 방법
	@Override
	public int calcPrice(int price) { //적립률 계산: 부모의 기능+할인률 계산 기능 추가:자식의 기능 추가
		bonusPoint+=price*bonusRatio;
		return price - (int) (price*saleRatio); // double을 반환하기 때문에 int로 형변환해서 계산
	}
	
	@Override
	public String showCustomerInfo() {
		return super.showCustomerInfo()+"담당 상담사는 "+agentID+"입니다."; //이름이 같은거 헷갈릴 수 있으니 부모꺼라고 super을 표시해준거임
	}


	// 메서드를 통해 VIP 고객 담당 상담원 아이디 값에 접근한다. (은닉화)
	public int getAgentID() {
		return agentID;
	}

}
