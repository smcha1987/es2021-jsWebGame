package edu_20230118.hk.day12_book;

public class GoldCustomer extends Customer {
	
//멤버필드 
	double saleRatio; // 할인율
	
//생성자 오버로딩
	public GoldCustomer(int customerID, String customerName) {
		super(customerID, customerName);
		customerGrade="Gold";
		bonusRatio=0.02;
		saleRatio=0.1; //해당 클래스에 있는 고유한 거지만 이름이 같은게 없어서 안헷갈림 this 생략한거임
	}

//메서드 오버라이딩
	@Override
	public int calcPrice(int price) {
		bonusPoint+=price*bonusRatio; //보너스 포인트 적립 //bonusPoint=bonusPoint+(int)(price*bonusRatio);
		return price-(int)(price*saleRatio); //가격 할인 적용
	}
}
