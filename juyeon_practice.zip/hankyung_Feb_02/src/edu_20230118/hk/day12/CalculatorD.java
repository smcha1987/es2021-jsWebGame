package edu_20230118.hk.day12;

//곱셈
public class CalculatorD extends Calculator {
	
	public CalculatorD() {  //생성자
	}

	public CalculatorD(int num1, int num2) {
		super.num1 = num1;
		super.num2 = num2;
	}

	// 곱하기 연산 가능
	@Override //오버라이딩 
	public int a() {
		int result = super.num1*super.num2;
		return result;
	}

}
