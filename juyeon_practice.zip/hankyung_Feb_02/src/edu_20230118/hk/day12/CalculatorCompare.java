package edu_20230118.hk.day12;

public class CalculatorCompare {
	
	//은닉화(캡슐화)
	private int result;//연산 결과값을 저장할 맴버필드

	public void calculator(int num1,int num2, String cal) {
		//분기형태
//		↓ 부모 클래스(하나의 타입)에 아래 여러개 자식 클래스(여러개의 타입) 실행 된다는 걸 알 수 있음
		Calculator calcu=null; 
		if(cal.equals("+")) {
			calcu=new CalculatorA(num1,num2);//num1,num2의 초기값을 넣어준다
			System.out.println(calcu.num1+"와"+calcu.num2+"의 덧셈을 실행합니다.");
		}else if(cal.equals("-")) {
			calcu=new CalculatorB(num1,num2);
			System.out.println("뺄셈을 실행합니다.");
		}else if(cal.equals("/")) {
			calcu=new CalculatorC(num1,num2);
			System.out.println("나눗셈을 실행합니다.");
		}else if(cal.equals("*")) {
			calcu=new CalculatorD(num1,num2);
//			result(new CalculatorD(num1,num2)); //참조타입을 파라미터로 전달할 경우
			System.out.println("곱셈을 실행합니다.");
		}else {
			System.out.println("입력내용을 확인하세요");
		}
		result(calcu);//a에서 실행된 결과를 result에 저장한다. // 하나의 부모가 자식 클래스를 만나서 a가 + - * /로 여러개 기능이 실행된다! (다형성)

	}
	public void result(Calculator calcu) { //부모클래스로 받음
		result=calcu.a(); //a() 메서드가 Calculator에 존재하기 떄문에 바로 사용가능
		
//		public void result(Object calcu) {
//			Calculator ccc=(Calculator) calcu; //Object는 a() 메서드가 없기때문에 형변환해야함!
//			result=ccc.a();
//			}
		
	}
	//맴버필드 result 값을 가져오는 기능
	public int getResult() {
		return result;
	}


}
