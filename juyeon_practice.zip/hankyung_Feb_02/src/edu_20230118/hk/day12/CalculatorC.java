package edu_20230118.hk.day12;

//나눗셈
public class CalculatorC extends Calculator {
	
	public CalculatorC() {  //생성자
	}

	public CalculatorC(int num1, int num2) {
		super.num1 = num1;
		super.num2 = num2;
	}

	// 나눗셈 연산 가능
	@Override //오버라이딩 
	public int a() {
		int result = super.num1 /super.num2;
		return result;
	}

}
