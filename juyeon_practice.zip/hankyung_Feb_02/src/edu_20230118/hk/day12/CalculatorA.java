package edu_20230118.hk.day12;

//덧셈
public class CalculatorA extends Calculator { //부모꺼 상속! 부모꺼 다 내꺼임~ 

	public CalculatorA() { //생성자
	}

	public CalculatorA(int num1, int num2) {
		super.num1 = num1; //super. (.은 들어가고 들어가고(~안에-".")) //부모꺼는 super로 나타냄 부모꺼 num1 가져오는거임
		super.num2 = num2;
	}

	// 덧셈연산 기능 --> 부모 클래스가 추상클래스라서 강제적으로라도 무조건 구현!!
	@Override //오버라이딩 
	public int a() { //부모 int꺼 가져와서 재정의
		int result = super.num1+super.num2;
		return result;
	}

}
