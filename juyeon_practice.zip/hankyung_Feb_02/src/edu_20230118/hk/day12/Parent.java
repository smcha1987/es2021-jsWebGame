package edu_20230118.hk.day12;

public class Parent {
	
	public int a; // 멤버필드
	
	public Parent() { // 생성자
		System.out.println("부모의 생성자 입니다.");
	}
	
	public Parent(int a) { // 생성자 오버로딩
		System.out.println("부모의 생성자 오버로딩 입니다.");
	}
	
	public void parentMethod() { //메서드
		System.out.println("부모의 메서드 입니다. : parentMethod");
	}

}
