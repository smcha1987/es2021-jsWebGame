package edu_20230118.hk.day12;

//뺄셈
public class CalculatorB extends Calculator {

	public CalculatorB() {
	}

	public CalculatorB(int num1, int num2) {
		super.num1 = num1; //부모꺼는 super로 나타냄 부모꺼 num1 가져오는거임
		super.num2 = num2;
	}

	// 뺄셈연산 기능
	@Override //오버라이딩 
	public int a() {
		int result = super.num1-super.num2;
		return result;
	}

}
