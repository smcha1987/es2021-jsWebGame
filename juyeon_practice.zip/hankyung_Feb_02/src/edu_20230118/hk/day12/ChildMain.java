package edu_20230118.hk.day12;

public class ChildMain {

	public static void main(String[] args) { //main +ct+space
		Child child=new Child(); // 자식타입으로 자식을 생성 -> 부모가 같이 생성됨
		child.parentMethod();
		child.childMethod(); //자식에서만 구현한 메서드
		System.out.println(child); //오버라이딩
								//child.toString() -> child으로 생략되어있는거임
		
		Parent parent=new Child() ; //부모의 타입으로 자식을 생성 (다형성)
		parent.parentMethod();
		Child child2=(Child)parent; //작은거->큰거로 담는거라서 형변환(캐스팅) 해줘야함 //int ii=(int)0.5
		child2.childMethod(); //자식타입으로 형변환하면 자식 메서드 사용 할 수 있다.
//		parent.childMethod(); // 자식에서만 구현한 메서드를 호출못함
		System.out.println(parent); //parent.toString() -> child으로 생략되어있는거임
		
		Parent parent2=new Parent() ; //부모의 타입으로 부모를 생성
		parent2.parentMethod();
		System.out.println(parent2); //parent2.toString() -> child으로 생략되어있는거임

	}

}
