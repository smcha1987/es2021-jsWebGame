package edu_20230118.hk.day12;

public class Child extends Parent{ //extends로 상속을 받았음! 자식 extends 부모
	
	public Child() { // 생성자
		super(); //부모 생성자 super가 생략되어 있는거임! super는 가장 윗줄(첫줄)에!!
				//	자식을 호출했더니 부모가 먼저 호출 됨
//		this(5); // 자기 클래스에서 부르기 this -->여기선 아래 public Child(int a) 가져오는거임
//				// 생성자 안에서는 생성자를 1번만 호출 할 수 있음 --> super와 this 모두 불러 오기 안됨!
		System.out.println("자식의 생성자 입니다.");
	}
	
	public Child(int a) { // 생성자 오버로딩
//		super(); //부모 생성자 super가 생략되어 있는거임! super는 가장 윗줄에!!
		super(a); //부모 생성자 super가 생략되어 있는거임! super는 가장 윗줄에!!
				//	자식을 호출했떠니 부모가 먼저 호출 됨
		System.out.println("자식의 생성자 오버로딩 입니다.");
	}
	
   //자식에만 있는 메서드
	public void childMethod() {
		System.out.println("자식에서만 구현된 메서드입니다.");
		
	}
	
	//오버라이딩: 부모의 메서드를 자식에서 재정의한다!
	@Override
	public void parentMethod() {
//		super.parentMethod(); //부모의 메소드를 실행해라
		System.out.println("자식이 주변 환경에 맞게 코드를 다시 재정의해서 사용한다."
							+ ":parentMethod()"); //컨케이트네이션 +로 문자열 묶어줌
	}
	
	@Override
		public String toString() { //toString은 Object라는 대왕 부모이기 떄문에 
			// Object의 메서드이고, 기능 : 기본타입의 경우 값을 문자열 반환
			//                       : 참조타입의 경우 주소@해시코드를 문자열로 반환
			return"나는 Child 객체 입니다.";
		}

}
