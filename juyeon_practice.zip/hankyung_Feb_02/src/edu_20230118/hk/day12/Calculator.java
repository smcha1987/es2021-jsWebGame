package edu_20230118.hk.day12;

// 클래스간에 상속관계 형성->계층구조 형성
// 오버라이딩 개념, 사용방법 
// CalculatorCompare에서 factory pattern 이용해서 다형성 구현, 은닉화 구현

public abstract class Calculator { //부모 클래스
	
	// 저장할 변수 2개에 대한 맴버필드
	public int num1;
	public int num2;
	
	public Calculator() { //default 부모 생성자 - Calculator 부모 클래스 생성
		System.out.println("Calculator 부모 클래스 생성자");
	}
	
	//추상 클래스를 상속받으려면 추상메서드를 반드시 구현해야한다. 
	public abstract int a(); //--> 부모클래스에서는 정의하가기 어려우니 자식클래스에서 구현하쇼!
}
