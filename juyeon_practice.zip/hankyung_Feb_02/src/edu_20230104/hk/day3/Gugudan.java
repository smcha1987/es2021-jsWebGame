package edu_20230104.hk.day3;

public class Gugudan {


	private static boolean ture;

	public static void main(String[] args) {
		
//		[for문을 중첩으로 사용해보기 (2중for문)]
		
//		2단 : 2X1=2 ...
//		System.out.println("2X1="+(2*1));
//		System.out.println("2X2="+(2*2));
		
		for (int i = 1; i < 10; i++) {
			System.out.println("2X"+i+"="+(2*i));
		}
		
		System.out.println("======2~9단 연속======");
		
/* 과제)2~9단까지 한번에 다 출력되도록 해볼 수 있지 않을까?
    2중 for문을 사용해보자*/
		//	아래 for문이 10번 도는 돌고 위에 있는 for문으로 들어감
		for (int i = 2; i < 10; i++) { //2~9단까지 지정해 줄 값
			for (int j = 1; j < 10; j++) { //1~9까지 곱해질 값
				System.out.println(i+"X"+j+"="+(i*j));
			}			
		}
		
		System.out.println("======짝수단 뽑기======");
/*과제) 2~9단까지 출력하는데 짝수단만 출력하기
- 어떻게 짝수를 구별할것인가?
2~9까지의 숫자중에 짝수를 어떻게 알 수 있을까>*/
		for (int i = 2; i < 10; i++) { //2~9단까지 지정해 줄 값
			if(i%2==0) {
				for (int j = 1; j < 10; j++) { //1~9까지 곱해질 값
				System.out.println(i+"X"+j+"="+(i*j));
				}		
			}
		}
		System.out.println("======홀수단 뽑기======");
//		2~9까지의 숫자중에 홀수를 어떻게 알 수 있을까>*/
		for (int i = 2; i < 10; i++) { //2~9단까지 지정해 줄 값
			if(i%2!=0) {
				for (int j = 1; j < 10; j++) { //1~9까지 곱해질 값
				System.out.println(i+"X"+j+"="+(i*j));
				}	
			}
		}
	
	} //public static void main 꺼
	
} //public class 꺼