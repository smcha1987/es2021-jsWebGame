package edu_20230104.hk.day3;

import java.util.Iterator;

public class ControlFlow_for_while {

	public static void main(String[] args) {
		
/*[for문] : 정확한 범위를 표현할 수 있을 때(10번 돌리자 20번 돌리자)
		 헝태 1.for문  for (int i = 0; i < args.length; i++) {
			 2.향상된 for문 */

//		for (int i = 0; i < s.length; i++) {-> 기본형태 : 범위를 설정하고 범위를 벗어나지 않는 상태에서 반복
//		i의 값이 5가 되는 순간 종료하자
		for (int i = 0; i <= 10; i++) {
			if(i==5) {
//			 break; - 이 코드가 실행되면 반복문 바로 종료
			 continue;
//			이 코드가 실행되면 가장 가까운 반복문으로 돌아간다
			}
		System.out.println(i);}
	
		
// String[] s= {"a","b","c"}; //배열: 같은 타입의 나열 -> 변수는 값 하나만 저장
		
/*향상된 for문
for (String string : s) {
System.out.println(string);*/
		
/* for (Map.Entry<keyType, valType> entry : map.entrySet()) {
keyType key = entry.getKey();
valType val = entry.getValue();*/
		
		System.out.println("=================while문===============");
/*[while문] : 범위를 모르면 사용 (조건에 의해 맞으면 계속 돌고 아니면 종료하고)*/
		int i=0;
		while(true) {
			System.out.println(i);
			if(i>10) {
				break;
			}
			i++;//i 값을 1씩 증가시켜줌
			}
		
//		조건식
		int ii=0;
		while(ii<=10) {
				System.out.println(ii);
				ii++;
				}
		/*	for문과 while문이 사용되는 상황
		 - 반복의 범위가 명확할떄 for문, 그렇지 않으면 while문을 사용한다.(절대적인건 X)*/
		
/*[do while문] - do{실행코드}while(조건문) : 조건이 false여도 최소한 한번은 실행한다.)*/
		do{
			System.out.println("최소 한번은 실행된다");
		} while(10<5);
		

		
	}
}
			
				
					
		