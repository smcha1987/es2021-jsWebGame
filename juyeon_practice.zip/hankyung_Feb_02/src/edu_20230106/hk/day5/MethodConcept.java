package edu_20230106.hk.day5;

public class MethodConcept { 
//	Method? 입력을 가지고 어떤 일을 수행한 다음에 결과물을 내어놓는 것

//    접근제한자  static/non-static  반환타입(void/타입[int,double...])    메서드명(변수선언)  
		public      static          void                            main(String[] args) {
//			test2();
			MethodConcept methodTest=new MethodConcept();//methodTest 주소를 찾아서 메서드를 찾아주는 형태
						methodTest.test007(10); //힙 메모리에 올라가있는 (static과 동급) 상황
		}
		
// [메서드의 유형]
// - 1.static/non-static
	public static void test001() {} //https://beforb.tistory.com/28
	public void test002() {}
	
// - 2. 반환타입 O, X
	public int test003() {return 5;} //반환 타입 O --> return과 int자리에 있는  모두 작성해줘야함!
	public double test004() {return 5.5;} //반환 타입 O --> return과 double자리에 있는  모두 작성해줘야함!
	public void test005() {} //반환 타입 X-->return 작성하면 안됨!
	
// - 3. 파라미터 O, X(default)
//	파라미터를 선언하면 호출할때 반드시 값을 전달해서 호출해야한다.
	public int test006(int a) { //int a에 test007에 있는 int num 10을 받아온거임
		return a+5;
	}
	public void test007(int a) { //int a 자리에 int a, int b, long l 등등 넣을 수 있음! 
								/* methodTest.test007(10); 
								// L 자리에 값을 꼭 넣어줘야함 파라미터를 선언하면 호출할때 반드시 값을 전달해서 호출해야한다.*/
		int num=a;
		int num2=test006(num); //int형의 값을 반환 (15 return에서 돌아온 값 10+5) 
		System.out.println(num2);
	}
	
		
		
//모든 곳에서 접근이 가능하고, 반환타입이 없고, 파라미터도 없는 메서드 (= 반환 타입 X 파라미터 X, static)
		public static void test() { 
			int a=5;
			System.out.println(a);
		}
		
		public static void test2() {
			test();// 메서드명()--> 메서드를 실행시킨다.
		}

	} //public class MethodTest 꺼임