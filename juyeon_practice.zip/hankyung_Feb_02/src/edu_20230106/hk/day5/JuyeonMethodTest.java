package edu_20230106.hk.day5;

public class JuyeonMethodTest {

	int sum(int a,int b) { //sum은 int a와 b를 받는다.
		return a+b; //a+b의 값을 sum에 넣는다.
	}
	
	public static void main(String[]args) { //main에서 실행시킬 수 있어서 위에서 아무리 쳐봤자 소용 없음
		int a=3;
		int b=4;
		
		JuyeonMethodTest yoyoyo = new JuyeonMethodTest(); //class명  객체명 =new class명(); //new: 클래스타입 객체 생성
		int c=yoyoyo.sum(a,b);
		
		System.out.println(c);
		
	}

}
