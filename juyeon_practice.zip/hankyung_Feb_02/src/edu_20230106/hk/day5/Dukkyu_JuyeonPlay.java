package edu_20230106.hk.day5;

import java.util.Scanner;

public class Dukkyu_JuyeonPlay {

	public static void main(String[] args) {
		boolean love = true;
		int heart = 1; 
		Scanner scan=new Scanner(System.in); 
		
		while (love) {
			System.out.println("♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥");
			System.out.println("1.엄청 사랑해|2.조금 사랑해|3.조금 안사랑해|4.안사랑해");
			System.out.println("♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥♡♥");
			System.out.println("선택>");
			int dukkyu=scan.nextInt(); //scan:위에 있는 스캔
			
			if (dukkyu==1) {
				System.out.println("잘했습니다! 나도 사랑합니다!");

			}else if(dukkyu==2){
				System.out.println("에게? 대화가 필요하겠군요.");
				
			}else if(dukkyu==3){
				System.out.println("으에?? 면담이 필요하겠군요..");
				int a=scan.nextInt(); 
				System.out.println("상담이 필요합니다.");
				
			}else if(dukkyu==4){
				System.out.println("그런 답은 존재할 수 없습니다. 다시 선택하세요.");
			continue;
			
			}else {
				System.out.println("정신차리세요!");
				break;
			}
			}
		
	} //public void printResult(int balance) 꺼임

} //public class BankTest_SwitchCase꺼임
