package edu_20230113.hk.day9;

public class AntMain {

	public static void main(String[] args) {
		AntQuiz ant=new AntQuiz();
//		ant.antMake(6);
		ant.antPrint(5);
	}
}
