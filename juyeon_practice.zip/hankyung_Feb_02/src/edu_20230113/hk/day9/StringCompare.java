package edu_20230113.hk.day9;

import java.util.StringTokenizer;

public class StringCompare {
	
	public static void main(String[]args) {
		
// String 비교 ==와 equals / equals 사용법 : (비교대상1.equals(비교대상2));
		//리터럴과 리터럴 비교
		String s1="java";
		String s2="java";
		System.out.println(s1==s2); //s1과 s2의 주소가 같음!
		System.out.println(s1.equals(s2)); // hashcode가 같다.
		
		//객체와 객체 비교
		String obj1=new String("java");
		String obj2=new String("java");
		System.out.println(obj1==obj2); //obj1과 obj2의 주소가 다름
		System.out.println(obj1.equals(obj2)); // hashcode는 문자열이 같기때문에 같다!
		
		//리터럴과 객체의 비교
		String s3="java";
		String obj3=new String("java");
		System.out.println(s3==obj3); //s3과 obj3의 주소가 다름
		System.out.println(s3.equals(obj3)); // hashcode는 문자열이 같기때문에 같다!
		
//	String Buffer를 사용한 문자열 변경하기(더하기)
		// String 리터럴 방식은 값이 바뀔 떄마다 객체를 새로 생성한다. --> 메모리 효율이 안좋음
		
		String ssss="가"; //
			   ssss=ssss+"나";
			   ssss=ssss+"다";
		
		StringBuffer sb=new StringBuffer("가");
		sb.append("나");
		sb.append("다");
		System.out.println(ssss+":"+sb.toString()); 
		
//	StringTokenizer를 이용한 문자열 자르기 --> 공백 없이 출력
		String source = "100,200,300,,400";
		StringTokenizer st=new StringTokenizer(source,",");
		while(st.hasMoreElements()) {
			System.out.println(st.nextToken());
		}
		
//	StringSplit를 이용한 문자열 자르기 --> 공백 있게 출력
		String source2 = "100,200,300,,,400";
		String[]arry=source2.split(","); //배열로 리턴
		for (int i = 0; i < arry.length; i++) {
			System.out.println(arry[i]);
		}
		
		
	}

}
