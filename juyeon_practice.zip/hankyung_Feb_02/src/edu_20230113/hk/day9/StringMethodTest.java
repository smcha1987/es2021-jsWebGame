
package edu_20230113.hk.day9;

public class StringMethodTest {
//String 주요 메서드 ★★★★★
//  1.문자 하나를 반환: charAt(int index)
	public String sTest01(String s) {
		String str=s.charAt(1)+""; //char는 기본타입이라서 String 참조타입으로 못가잖아!
									// --> 문자열을 만나면 문자열이 된다. Concatenation 
		String str2=String.valueOf(s.charAt(2)); //↑ 또는 String.valueOf-->기본타입을 문자열로 변환
		int i=Integer.parseInt("100"); //숫자형태의 문자열-->int형으로 변환
		return str;
	}
	
//	2.문자열의 인덱스를 반환 : indexOf(String s) / lastIndexOf (다르진 않지만 어떻게 검색을 할건지 차이!)
//	"최강야구" 
//   0 1 2 3 --> "강"이라는 글자의 위치는?
//	indexOf(s) --> 원하는 s가 존재한다면 해당 인덱스를 반환, 없으면 -1을 반환하게 
//	indexOf         ,      lastIndexOf
//	-> 왼쪽->오른쪽으로 검색,    ->오른쪽->왼쪽으로 검색
	public String sTest02(String s) {
		int num1 = s.indexOf("최");
		int num2 = s.indexOf("강야"); //2글자 이상일 경우 해당 문자를 찾고 그 첫번쨰 문자 인덱스 반환
		int num3 = s.lastIndexOf("구");
		int num4 = s.indexOf("동");
		
		if (s.indexOf("최고")!=-1) { //조건식으로 활용: 문자열 중에 "최고"라는 단어가 존재한다면
			
		}
		
		return num1+","
				+num2+","
				+num3+","
				+num4;
	}
	
//	3.문자열의 길이 반환:length()
	public int sTest03(String s) {
		return s.length();
	}
	
//	4.문자열의 내용을 바꾸는 기능: replace("원본","새로운 내용")
	public void sTest04() {
		String s="자바 프로그래밍";
		String ss=s.replace("자바", "파이썬"); //새로 대입해줘야함 ss로 넣은거처럼!!
		System.out.println(s+":"+ss);
	}
		
//★★5.문자열에서 원하는 내용만 추출하는 기능:substring(int start,int end) 
//	(1) substring(int startIdx) (2) substring(int startIdx,int Idx) --> 특성 : 다음글씨를 포함하지 않고 인식
	public String sTest05(String s) {
		String str=s.substring(3); //문자열의 3번쨰 인덱스부터 끝까지 추출
		String str2=s.substring(0,2); //문자열의 0번쨰 인덱스부터 2번째(3-1번쨰)까지 추출
		return str+":"+str2;
	}

//  연습하기!
// 1. 해당 검색어가 존재하는 여부 판단 
	public void search(String s) {
		
		String txt = "전문가들은 마스크를 벗으면 고위험군의 안전이 위협받을 것을 가장 우려하고 있다.\r\n"
				+ "김 교수는 “60대 이상의 개량 백신 접종률이 30%대에 그치는 데, 설 연휴에 고향의 어르신을 찾아뵈면서 코로나19를 전파할 가능성이 있다”라며 “위중증 사망자가 늘 수 있는 위험천만한 상황”이라고 진단했다.\r\n"
				+ "신 위원장은 “마스크 착용이 느슨해지면 고위험군의 피해는 늘어날 수밖에 없다”면서 “먼저 마스크를 벗은 미국의 경우 100만 명 넘게 사망하고 의료시스템도 마비됐다”고 지적했다.\r\n"
				+ "현재 미국과 유럽 등 해외 주요국은 마스크 착용 의무 조치가 없거나 의료시설·대중교통 등을 중심으로 의무를 유지하고 있다. 아시아에서도 싱가포르와 필리핀 등이 일부 시설을 제외하고 실내 마스크를 해제했다.";
	
		if(txt.indexOf(s)!=-1) { //해당단어가 존재한다면... (-1이 아닌 경우가 참이니까!)
			System.out.println("검색어를 찾았습니다!");  // 검색된 단어를 처리할 코드
		} else { 
			System.out.println("검색어가 존재하지 않습니다.");  //해당 단어가 없는 경우 처리할 코드
		}

// 2. 해당 검색어의 인덱스 구해보기 (가장 처음나온거만 나옴)
		if (txt.indexOf(s) != -1) { // 해당단어가 존재한다면... (-1이 아닌 경우가 참이니까!)
//			System.out.println("검색어를 찾았습니다!"); // 검색된 단어를 처리할 코드
			int idx=txt.indexOf(s);
				System.out.println(s+"의 위치값은 "+idx+"입니다.");
		} else {
			System.out.println("검색어가 존재하지 않습니다."); // 해당 단어가 없는 경우 처리할 코드
		}

// 3. 해당 검색어를 추출해서 출력해보기 substring() 사용!
//	(1) substring(int startIdx) (2) substring(int startIdx,int Idx) --> 2번을 써보자! "마스크"
//																					6 7 8 --> 길이값을 알아봐야겠군
		if (txt.indexOf(s) != -1) { // 해당단어가 존재한다면... (-1이 아닌 경우가 참이니까!)
			int idx=txt.indexOf(s); //첫번쨰 인덱스 시작 위치 구하기
				String ss=txt.substring(idx, idx+s.length()); // 단어 길이값 구하기 (값이 바뀐게 아니라서 string에 담아준거임)
				System.out.println("추출한 검색어: "+ss+"입니다.");
		} else {
			System.out.println("검색어가 존재하지 않습니다."); // 해당 단어가 없는 경우 처리할 코드
		}

// 4. 해당 검색어를 문자열에서 ###로 바꿔주기
		if (txt.indexOf(s) != -1) { // 해당단어가 존재한다면... (-1이 아닌 경우가 참이니까!)
				String txtAfter=txt.replace(s, "###"); //기존의 값을 새로운 값으로 바꾸기 (값이 바뀐게 아니라서 string에 담아야함)
				System.out.println(txtAfter);
		} else {
			System.out.println("검색어가 존재하지 않습니다."); // 해당 단어가 없는 경우 처리할 코드
		}
	
// 5. 해당 검색어의 검색된 개수 구해보기! -> 여기서 호출해보기
		isIndexCount(txt,s);
	} //public void search(String s)
		
	public void isIndexCount(String txt, String s) { //()안에 블럭 단위로 생각하기 떄문에 이름 같아도 상관 없음
		int count=0;
		int idx=0;
		while(txt.indexOf(s,idx)!=-1) { //검색어가 몇번이나 나올지 모르니 for문보단 while문이 더 좋을듯!
			count++; //첫번째 걸리는 idx부터 계속 증감연산해서 개수 세기
			idx=txt.indexOf(s,idx)+s.length(); //해당 단어의 마지막 단어 위치 다음 인덱스를 구함 -> 그 인덱스부터 검색하기위해
		}
		System.out.println(s+"의 검색된 개수는 "+count+"이다.");
	} //public void isIndexCount(String txt, String s


} //public class StringMethodTest
