//예외 처리 - Exception
package edu_20230126.hk.day16;

import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionTest {

	public static void main(String[] args) { 
		
		try {
			userExceptionTest(20);
		} catch (UserException e) {
			System.out.println("발생한 예외를 처리합니다.");
			e.printStackTrace();
		}
		
		exTest("1234"); //argument: 값, 예외처리, null 넣을때 마다 다른 Exception 발생

	}
	
	public static void exTest(String s) {
		int i=0;
		String ss="";
		int [] array= {1,2,3,4,5};
		
		try { // 에러가 발생할 소스
			System.out.println("예외가 발생할 가능성이 있는 코드 작성");
			ss=s.substring(0, 2); //예외가 발생한 코드에서 바로 catch로 이동하기 때문에 ↓ 여기 작성하면 실행 안됨
//			System.out.println("예외가 발생할 가능성이 있는 코드 작성");
			i=Integer.parseInt(ss); // String을 int형으로 변환 --> NumberFormatException 자주 발생!
			int a=array[5]; //index를 5 사용 -> 4까지 밖에 없는디!
			
		} catch (StringIndexOutOfBoundsException se) { //Exception과 바꾸면 안됨! 이게 세밀하게 잡아주는거라서 먼저쓰고 가장 큰 범위인 Exception으로!
			System.out.println(se+"\n:문자열의 길이를 확인하세요."); //\n 줄바꿈
		} catch (IndexOutOfBoundsException ie) { //catch는 여러개 사용 가능
			System.out.println(ie+"\n:배열의 길이를 확인하세요."); //\n 줄바꿈
		} catch (NullPointerException | NumberFormatException en) { // | 한줄에 여러개 작성하게 해주는거! (첫번쨰꺼 또는 두번째꺼 중 하나라도 걸리면 해주겠다!)
			System.out.println(en+"\n:해당 객체의 형식을 확인하세요."); //\n 줄바꿈
		} catch (Exception e) { //catch 블록의 내용이 처리 에러를 처리
			System.out.println("다중 Catch문을 작성할 떄 유의 사항"
								+ "Exception 클래스를 작성한느 순서: 하위 클래스->상위 클래스 순으로 작성");
			e.printStackTrace(); //오류를 잡아주는 코드를 안해주면 오류를 볼 수 없어요! 지우면 안됨!!
		}finally { //오류 발생하고 catch에서 잡아주고 끝나도 여기 있는건 무조건 실행!
			System.out.println("반드시 처리할 코드 실행"); 
		}
	}
	//throws: 예외 던지는 방법
	public void test03() {
			try {
				test01(); //3. 예외를 던지면 반드시 마지막에는 직접 처리해야한다.
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

	public void test01() throws IOException, NullPointerException { //여러개 던지겠다 --> ,로 하면 됩니닷
		int i=0;
		System.out.println("예외를 직접 처리하지 않는다.");
			test02(); //2. 예외를 또 던질 수 있다.
	}

	public void test02() throws IOException { //여기서 못해ㅠㅠ 다른곳에서 처리해줘 --> 다른 곳으로 throws 해줘!
		InputStreamReader in= new InputStreamReader(null);
		in.read(); //1. 빨간줄 오류 남 --> checkedException이라서 무조건 주욤이 예외처리 해야함!

	}
	
	// 사용자 예외처리
	public static void userExceptionTest(int a) throws UserException {
		//a는 1~10까지만 받을 수 있는 상황
		if (!(a>0&&a<11)) { //조건식 1~10 범위를 벗어나는 숫자이면 true -if문 실행
			throw new UserException("1부터 10까지만 입력이 가능합니다.");
		}
	}

}
