//사용자 예외처리
package edu_20230126.hk.day16;

public class UserException extends Exception{ //내가 원하는거 쓰고 싶으면 Exception을 상속 받아야해
	
	public UserException() {
		this("UserException 오류입니다.");
	}

	public UserException(String msg) {
		super(msg);  //부모의 생성자: Exception 클래스 호출

	}

}
