package edu_20230111.hk.day7; //저장된 경로를 패키지로 나타냄!

import edu_20230109.hk.day6.Divisor2; //다른 패키지에 있는걸 사용하는 경우  import

public class ConstructorMain {

	public static void main(String[] args) {
		//다른 클래스에 있는 메모리에 올라가있지 않은 non-static을 받아오는 방법!! (받아오는 파일 : ConstructorTest)
		ConstructorTest ct=new ConstructorTest();
		ConstructorTest ct2=new ConstructorTest(50);
		ConstructorTest ct3=new ConstructorTest(65,"화이트"); 
		
		ct.setSize(50); //size는 메서드를 통해서만 바꿀 수 있음
		ct.setSize(50,1647);
		ct.color="핑크색"; //객체명.멤버필드로 접근하여 바꿀 수 있음
		ct.setColor("블랙"); //객체명.메서드로 접근하여 바꿀 수 있음
		System.out.println(ct.getSize()+":"+ct.color);
		
		
		// 같은 클래스 안에 있는 메모리에 올라가 있지 않은 non-static을 받아오는 방법!!
		ConstructorMain cm=new ConstructorMain();
		cm.test(); 
		
		//다른 클래스의 기능을 사용하고 싶으면 객체 생성해서 메서드를 호출해야한다
//		Divisor2 dv=new Divisor2();
//		System.out.println(dv.sumDivisor(20));

	} //public static void main(String[] args)
	
	public void test() {
		System.out.println("안녕하쇼");
	}

} //public class ConstructorMain
