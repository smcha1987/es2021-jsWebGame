// 생성자 오버로딩 연습하기!

package edu_20230111.hk.day7;

public class ConstructorTest{
	
//	public int size=0;
	private int size=0;  //private : 다른 클래스에서 접근이 안되미!
	public String color="검정색";
	
	public ConstructorTest() { //자식 생성자를 호출하면 ↓ 부모 생성자를 먼저 호출한다.
		// super는 항상 위에 있어야한다!
		super(); //생략가능+부모의 생성자를 호출한다. & 부모가 먼저 실행되어야하기 떄문에 가장 윗줄에 작성!)
		this.size = 20; //현재 클래스에 있는 멤버 필드에 있는 this! this. 넣어야함.
		System.out.println(size+"인치 검은색 텔레비전이 왔어요ㅋㅋㅋ");
	}
	
//생성자 오버로딩	
		public ConstructorTest(int size) {
//		super();
//		this(); //현재 클래스의 public ConstructorTest()를 호출하는거임
		this.size = size; //this.size는 멤버필드꺼고 size는 위에 있는 int size  꺼임
		System.out.println(size+"인치 검은색 텔레비전이 왔어요ㅋㅋㅋ");
	}
	

	public ConstructorTest(int size, String color) {
//		super();  //↓ㅅ위에서 호출하면 여기서는 쓰면 안되는거임!
//		this(size); //생성자끼리도 호출 가능 단, 생성자는 딱 한번만 실행된다!!!!
					//타고 타고 올라가서 public ConstructorTest()/ public ConstructorTest(int size) 모두 호출됨!
		this.size = size;
		this.color = color;
		System.out.println(size+"인치"+ color+" 텔레비전이 왔어요ㅋㅋㅋ");
	}
	
	// size와 color을 변경하는 기능 추가
//size는 변경하지 않을 수 있게 해보기! 1.멤버필드의 public int size=0; 를 private로 바꿔줌
	// 메서드를 통해서 size에 접근한다.	
	public void setSize(int size,int code) { //source-getter and setter 가져오면 이렇게 되는거임
		if(code==1234) {
			this.size=size;			
		}else {
			System.out.println("변경할 수 없습니다.");
		}
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	//색상을 변경하면서 변경내용을 출력해주는 메서드
	public void setColor(String color) {
		this.color=color;
		System.out.println("색상을 "+color+"로 변경합니다.");
	} //public void setColor(String color)


} //public class ConstructorTest 종료
