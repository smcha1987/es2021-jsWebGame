//IO(Input & Output) 실습해보기
package edu_20230127.hk.day17;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;

public class IoTest {

	public static void main(String[] args) {
		IoTest io = new IoTest();
//		io.test01();
//		io.test02();
//		io.test03();
//		io.test04();
		io.test05();

	}

// 파일을 읽고 출력하는 기능
	public void test01() {
		InputStream in = null; // 입력을 위한 파이프 설계도(껍데기) 준비
		OutputStream out = null; // 출력을 위한 파이프 설계도(껍데기) 준비

		try {
			in = new FileInputStream("D:\\HelloWorld.txt"); // 파일의 위치를 담고 있는 객체 생성 (파이프 집어넣을 연결 대상)
			out = new FileOutputStream("D:\\GoodbyeWorld.txt"); // 출력할 파일의 위치를 담고있는 객체 생성 (파이프 빼낼 연결 대상)

			int i = 0; // read 메서드에서 반환되는 값을 저장할 변수
//			보통 이렇게 쓰임 ↓ 풀어서 쓴것보다!!
			while ((i = in.read()) != -1) { // -1이 아니라면 true(실행)
				System.out.print((char) i);
				out.write(i); // 읽어들인 내용 그대로 송출!
			}
//			↑ 풀어서 쓰면 이렇게 되는거임
//			while (true) {
//				i = in.read(); // byte 단위로 파일의 내용을 읽어서 i에 저장한다.(실제 값 저장)
//				System.out.print((char) i);
//				out.write(i); // 읽어들인 내용 그대로 송출!
//
//				if (i == -1) { // -1: 더이상 읽을 값이 없으면 -1을 반환한다.
//					break;
//				}
//			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) { // try-while문 안에 i=in.read(); IOException 처리해준거임
			e.printStackTrace();
		} catch (Exception e) { // 못잡는거는 그냥 Exception으로 다 잡아줘라
			e.printStackTrace();
		} finally {
			try {
				out.close(); // 마지막에 실행된 것부터 닫아준다.
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// public void test01() 종료

// filter : 보조스트림
	public void test02() {

		OutputStream out = null; // 출력을 위한 파이프 설계도(껍데기) 준비
		DataOutputStream ds = null; // 보조 스트림(필터 스티림)

		String s = "파일을 기록합니다.";
		try {
			out = new FileOutputStream("D:\\outdata.txt"); // 주 스트림(노드 스트림)

			// 1. 보조 스트림(filter) 사용시
			ds = new DataOutputStream(out); // 보조 스트림 사용 - 필터 생성(성능 향상 시키는 느낌!)
			ds.writeUTF(s); // String s = "파일을 기록합니다.";가 byte 타입이 아니니 writeUTF가 byte로 해줌!
							// --> UTF-8 형식으로 인코딩된 문자열을 출력해준다. 문자열을 알아서 바이트로 나눠서 처리!
			// 2. 보조 스트림(filter) 미 사용시
//			byte[] b=s.getBytes(); //문자열(String s = "파일을 기록합니다.")을 byte 단위로 변환해서 배열로 반환한다!
//			out.write(b);
		} catch (FileNotFoundException e) {
			// 처리 코드 작성
			e.printStackTrace();
		} catch (IOException e) {
			// 처리 코드 작성
			e.printStackTrace();
		} finally {
			try {
				ds.close();// 마지막에 실행된 것부터 닫아준다.
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	} // test02 종료

// 한번 읽을때 크기를 설정해서 읽고 쓰기
	public void test03() {
		InputStream in = null; // 입력을 위한 파이프 설계도(껍데기) 준비
		OutputStream out = null; // 출력을 위한 파이프 설계도(껍데기) 준비

		try {
			in = new FileInputStream("D:\\testimage.jpg"); // 해당 파일을 읽기 위한 스트림 객체 생성
			out = new FileOutputStream("D:\\뀨야 커플.jpg");// 해당 파일을 복사해서 출력하기 위한 스트림 객체 생성
			// 10b 단위로 읽기 위한 가방을 만든다.
			byte[] b = new byte[10]; // 1kb=1024byte임
			int i = 0; // 읽어들인 갯수가 저장되는거! --> int read(byte b[]) :읽은 데이터 수 (박스 하나에 10개를 담았어도 박스 하나로 인식
						// → 갯수가 입력됨)
						// read()의 경우 실제 값이 저장(10개→ 10개)

			while ((i = in.read(b)) != -1) { // 1. b에 6이 들어감[1 2 3 4 5 6 7 8 9 10]
//				out.write(b);            //2. → 이렇게 해서 남는 자료가 있다면 [11 12 13 14 15 16 7 8 9 10] 이전 값은 사라지는게 아니라 남아있게됨!
				out.write(b, 0, i); // 3. ↑ 문제를 해결하기 위해 b배열의 0부터 길이i만큼 출력하자!는 out.write(b, 0, i); 3개 넣어지는거 사용!
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}// test03 종료

// Reader & Writer 클래스 
	public void test04() {
		InputStreamReader in = null;
		OutputStreamWriter out = null;
		System.out.println("====입력하세요.====");

		try {
			in = new InputStreamReader(System.in); // 키보드로 입력받고
			out = new OutputStreamWriter(System.out); // 콘솔에 출력할거얌!

			char[] ch = new char[512];
			int i = 0; // 읽어들인 갯수가 저장되는거! --> int read(byte b[]) :읽은 데이터 수 (박스 하나에 10개를 담았어도 박스 하나로 인식
						// → 갯수가 입력됨)
			while ((i = in.read(ch)) != -1) {
				out.write(ch, 0, i);
				out.flush(); // 남아있는 잔여물 다 밀어내기 해야함!! (스트림에 기록된 데이터를 강제로 모두 비운다.)
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// test04 종료
// 문자 단위로 읽는 Reader와 보조스트림을 활용하여 구현

	public void test05() {
		Reader reader = null; //추상클래스라서 객체 생성 불가!(부모 클래스임)
		BufferedReader br = null;

		try {
			File file = new File("D:\\HelloWorld.txt");
			reader = new FileReader(file); // 주스트림(노드 스트림)
			br = new BufferedReader(reader); // 보조스트림(필터 스트림)
			String str = "";
			while ((str = br.readLine()) != null) { // 문자열이기 때문에 -1이 아닌 null로 반환
				System.out.println(str); // 여러줄의 문자를 한줄 단위로 출력
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	} // test05 종료

}
